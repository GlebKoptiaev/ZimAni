#!/usr/bin/env python3
"""Record UART output from ZIMANI TX diagnostic firmware (230400 8N1).

Requires: pip install pyserial
Example: py record_diag.py --port COM5 --out tx_diag01.txt --seconds 30
Do not open the port simultaneously in the control GUI.
"""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import time

def utc_stamp():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--port', required=True)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--baud', type=int, default=230400, help='UART baud, default: 230400')
    p.add_argument('--seconds', type=float, default=30.0,
                   help='Duration, 0 = until Ctrl+C')
    p.add_argument('--verbose', action='store_true',
                   help='Print every line to console (slower on Windows)')
    a = p.parse_args()
    if a.seconds < 0:
        p.error('--seconds must be >= 0')
    try:
        import serial
    except ImportError as e:
        raise SystemExit('Install pyserial: py -m pip install pyserial') from e
    # Deliberately do NOT toggle DTR/RTS on every frame.
    # Opening ST-LINK VCP may still affect target reset on some host setups.
    a.out.parent.mkdir(parents=True, exist_ok=True)
    deadline = (time.monotonic() + a.seconds) if a.seconds else None
    records = 0
    with serial.Serial(a.port, a.baud, timeout=0.15) as ser, \
            a.out.open('w', encoding='utf-8', newline='\n') as log:
        log.write(f'#host_start={utc_stamp()}\n')
        log.write(f'#source=ZIMANI_TX_DIAG_v5 port={a.port} baud={a.baud}\n')
        try:
            while deadline is None or time.monotonic() < deadline:
                data = ser.readline(2048)
                if not data:
                    continue
                line = data.decode('utf-8', errors='replace').rstrip('\r\n')
                stamped = f'{utc_stamp()} {line}'
                log.write(stamped + '\n')
                records += 1
                if a.verbose or line.startswith(('D INIT ', 'D STAT ', 'D BAD_WIDTH ', 'S v=')):
                    print(stamped)
        except KeyboardInterrupt:
            pass
        finally:
            log.write(f'#host_stop={utc_stamp()} records={records}\n')
            log.flush()
    print(f'Saved {records} lines to {a.out}')

if __name__ == '__main__':
    main()
