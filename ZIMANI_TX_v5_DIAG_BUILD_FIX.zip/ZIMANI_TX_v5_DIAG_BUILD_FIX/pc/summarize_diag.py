#!/usr/bin/env python3
"""Summary of TX diagnostic logs. Validates diagnostics, no radio control."""
import argparse
from collections import Counter
from pathlib import Path
import re

DIAG = re.compile(r'(?:^|\s)D\s+(INIT|TX|DONE|RX|STAT|BAD_WIDTH)\s+(.*)$')

def parse_log(path):
    counts = Counter()
    latest_stat = None
    results = Counter()
    durations = []
    tx_ids = set()
    done_ids = set()
    rx_ok = Counter()
    init_ok = Counter()
    errors = []
    for line_no, line in enumerate(path.read_text(encoding='utf-8', errors='replace').splitlines(), 1):
        m = DIAG.search(line)
        if not m:
            continue
        kind, rest = m.groups()
        fields = dict(re.findall(r'([a-z_]+)=([^\s]+)', rest))
        counts[kind] += 1
        if kind == 'TX':
            if 'id' in fields:
                tx_ids.add(int(fields['id']))
            payload = fields.get('pay', '')
            if len(payload) != 52 or not payload.startswith('AA'):
                errors.append(f'Line {line_no}: unexpected TX payload ({len(payload)} hex digits)')
            if fields.get('ce') != '1':
                errors.append(f'Line {line_no}: TX recorded while CE != 1')
        if kind == 'DONE':
            if 'id' in fields:
                done_ids.add(int(fields['id']))
            results[fields.get('r', '?')] += 1
            if 'dt' in fields:
                durations.append(int(fields['dt']))
        if kind == 'RX':
            rx_ok[fields.get('ok', '?')] += 1
        if kind == 'INIT':
            init_ok[fields.get('ok', '?')] += 1
        if kind == 'STAT':
            latest_stat = fields
    return counts, results, durations, tx_ids, done_ids, rx_ok, init_ok, latest_stat, errors

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('file', type=Path)
    a = p.parse_args()
    c, result, durations, tx, done, rx_ok, init_ok, stat, errors = parse_log(a.file)
    print('File:', a.file)
    print('TX frames:', c['TX'])
    print('DONE frames:', c['DONE'])
    print('Results:', dict(result))
    print('RX payloads:', c['RX'], 'valid:', rx_ok['1'], 'invalid:', rx_ok['0'])
    print('INIT:', dict(init_ok), '| BAD_WIDTH:', c['BAD_WIDTH'])
    if durations:
        print('TX duration (us): min={} max={} mean={:.1f}'.format(
              min(durations), max(durations), sum(durations) / len(durations)))
    if tx:
        print('TX without logged DONE:', len(tx - done), 'IDs:', sorted(tx - done)[:10])
    if stat:
        print('Last device counters:', ' '.join(f'{k}={v}' for k,v in stat.items()
                                                if k in ('ack','fail','rx','badrx','spi_err','uart_drop','safe')))
        if int(stat.get('uart_drop','0')):
            print('WARNING: UART queue overflow: some diagnostic events are missing.')
        if stat.get('safe') != '1':
            print('WARNING: firmware was not in STOP-only mode.')
    if errors:
        print('Warnings:')
        for error in errors[:10]:
            print(' ', error)
    if not c['TX']:
        print('No TX events. Check firmware version and UART.')

if __name__ == '__main__':
    main()
