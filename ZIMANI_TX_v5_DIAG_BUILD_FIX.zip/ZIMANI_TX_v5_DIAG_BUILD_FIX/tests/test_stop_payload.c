#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "zimani_control.h"
int main(void)
{
 ZControl ctl;
 uint8_t p[26];
 z_init(&ctl);
 assert(ctl.command.estop == 1u);
 z_payload(&ctl.command,p);
 assert(p[0] == 0xAAu && p[9] == ENGINE_OFF);
 assert(p[11] == 0u && p[12] == 0u && p[13] == 0u);
 assert(p[15] == 0u && p[23] == 1u && p[25] == 0xEDu);
 uint8_t sum = 0u;
 for(unsigned i=0; i<24; i++) sum = (uint8_t)(sum + p[i]);
 assert(p[24] == sum);
 puts("STOP payload verified");
 return 0;
}
