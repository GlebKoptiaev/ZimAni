import unittest
from reader import parse_ce_capture, parse_capture, build_timeline


def sample(ce_count=4,flags='0x00000000',last_level=0):
    return (f'#BEGIN version=4 reason=WINDOW flags={flags} frames=3 '
            'complete_bytes=8 raw_mosi=8 raw_miso=8 raw_frames=3 '
            'total_sck=64 raw_times=3 ce_count='+str(ce_count)+' '
            'ce_start=0 ce_end='+str(last_level)+' ce_overflow=0 ce_duplicate=0 '
            'ce_source=pe5_exti_tim5_us timestamps=exti3_tim5_us latency=isr '
            'not_synchronized=1\n'
            '#F,index,end_sck,end_us,MOSI_hex,MISO_hex\n'
            'F,0,16,100,07FF,0E1E\n'
            'F,1,32,200,271E,1E00\n'
            'F,2,64,310,A0AABBCC,0E000000\n'
            '#C,index,t_us,level\n'
            'C,0,120,1\n'
            'C,1,145,0\n'
            'C,2,250,1\n'
            'C,3,280,0\n'
            '#END\n')


class V4CETests(unittest.TestCase):
    def test_parse_and_decode_combined_timeline(self):
        meta,spi,ce=parse_ce_capture(sample())
        self.assertEqual(meta['version'],'4')
        self.assertEqual([r['level'] for r in ce],[1,0,1,0])
        self.assertEqual([r['t_us'] for r in ce],[120,145,250,280])
        self.assertEqual(parse_capture(sample())[1][0]['data_hex'],'1E')
        tl=build_timeline(spi,ce)
        self.assertEqual([r['t_us'] for r in tl],[100,120,145,200,250,280,310])
        self.assertIn('MAX_RT',tl[0]['detail'])
        self.assertIn('CLEAR_STATUS',tl[3]['detail'])

    def test_reject_missing_ce_and_invalid_levels(self):
        with self.assertRaisesRegex(ValueError,'Header CE count'):
            parse_ce_capture(sample(ce_count=3))
        with self.assertRaisesRegex(ValueError,'CE final level'):
            parse_ce_capture(sample(last_level=1))
        with self.assertRaisesRegex(ValueError,'Repeated CE level'):
            parse_ce_capture(sample().replace('C,1,145,0','C,1,145,1'))
        with self.assertRaisesRegex(ValueError,'Nonmonotonic CE'):
            parse_ce_capture(sample().replace('C,1,145,0','C,1,90,0'))
        with self.assertRaisesRegex(ValueError,'Invalid CE event'):
            parse_ce_capture(sample().replace('C,0,120,1','C,0,120,2'))

    def test_reject_flags_without_explicit_override(self):
        with self.assertRaisesRegex(ValueError,'flags'):
            parse_ce_capture(sample(flags='0x400'))
        self.assertEqual(len(parse_ce_capture(sample(flags='0x400'),True)[2]),4)

if __name__=='__main__': unittest.main()
