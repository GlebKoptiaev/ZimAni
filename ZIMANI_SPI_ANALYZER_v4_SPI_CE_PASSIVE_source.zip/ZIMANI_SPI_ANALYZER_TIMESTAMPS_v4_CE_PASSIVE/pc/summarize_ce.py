#!/usr/bin/env python3
"""Summarize CE edges and SPI STATUS after v4 capture (no new dependencies)."""
import argparse
from pathlib import Path
import statistics
from reader import parse_ce_capture,build_timeline


def describe_capture(meta,spi,ce):
    print('Capture:',f"flags={meta.get('flags')}",f"reason={meta.get('reason')}")
    print('SPI frames:',len(spi),'CE edges:',len(ce),
          'CE start/end:',meta.get('ce_start'),meta.get('ce_end'))
    if meta.get('ce_overflow') not in (None,'0') or meta.get('ce_duplicate') not in (None,'0'):
        print('WARNING: CE overflow or duplicated edges; examine raw data.')
    level=int(meta.get('ce_start',0))
    rise=None
    durations=[]
    for ev in ce:
        if ev['level']==1:
            rise=ev['t_us']
        elif rise is not None:
            durations.append(ev['t_us']-rise)
            rise=None
    if durations:
        print('Complete CE HIGH pulses:',len(durations),'min/median/max us:',
              min(durations),statistics.median(durations),max(durations))
    else:
        print('No complete CE HIGH pulse observed (a constant level can be valid).')
    events=build_timeline(spi,ce)
    interesting=[ev for ev in events if (ev['type']=='CE'
           or ev['event']=='W_TX_PAYLOAD'
           or ev['event']=='R_REGISTER' and ev['register']=='STATUS'
           or ev['event']=='W_REGISTER' and ev['register']=='STATUS')]
    print('Events for first 50 interesting timeline entries (relative microseconds):')
    for ev in interesting[:50]:
        d=ev['detail']
        print(f" {ev['t_us']:>8}  {ev['type']:>3}  {ev['event']:<18} "
              f"{str(ev['level']):>2}  {d}")
    status=[ev for ev in interesting if ev['type']=='SPI' and 'READ_STATUS=' in ev['detail']]
    maxrt=[e for e in status if '[MAX_RT' in e['detail'] or '+MAX_RT' in e['detail']]
    print('STATUS reads:',len(status),'reads with MAX_RT bit:',len(maxrt))
    if maxrt:
        print('First 8 MAX_RT reads and subsequent CE edges within 50ms:')
        ce_events=[ev for ev in events if ev['type']=='CE']
        for e in maxrt[:8]:
            future=[(c['t_us']-e['t_us'],c['event']) for c in ce_events
                    if 0<=c['t_us']-e['t_us']<=50000]
            print(f"  t={e['t_us']}us: {future[:15]}")
    print('Note: CE EXTI timestamps have interrupt latency; no radio RX ACK conclusion'
          ' should be drawn from STATUS reads alone.')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('input')
    ap.add_argument('--allow-partial',action='store_true')
    a=ap.parse_args()
    meta,spi,ce=parse_ce_capture(Path(a.input).read_text(encoding='ascii'),a.allow_partial)
    if meta['version']!='4': raise SystemExit('v4 file with CE events required')
    describe_capture(meta,spi,ce)

if __name__=='__main__':main()
