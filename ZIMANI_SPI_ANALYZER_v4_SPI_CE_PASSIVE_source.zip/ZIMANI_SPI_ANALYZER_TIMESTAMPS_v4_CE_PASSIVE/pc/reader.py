#!/usr/bin/env python3
"""Record/decode F429 SPI+CE UART captures (v1/v2/v3/v4), Python 3.9+."""
import argparse
import csv
from pathlib import Path
import re
import sys
import time

REG = {0x00:'CONFIG', 0x01:'EN_AA', 0x02:'EN_RXADDR', 0x03:'SETUP_AW',
       0x04:'SETUP_RETR', 0x05:'RF_CH', 0x06:'RF_SETUP', 0x07:'STATUS',
       0x08:'OBSERVE_TX', 0x09:'RPD', 0x0A:'RX_ADDR_P0', 0x0B:'RX_ADDR_P1',
       0x0C:'RX_ADDR_P2', 0x0D:'RX_ADDR_P3', 0x0E:'RX_ADDR_P4', 0x0F:'RX_ADDR_P5',
       0x10:'TX_ADDR', 0x11:'RX_PW_P0', 0x12:'RX_PW_P1', 0x13:'RX_PW_P2',
       0x14:'RX_PW_P3', 0x15:'RX_PW_P4', 0x16:'RX_PW_P5', 0x17:'FIFO_STATUS',
       0x1C:'DYNPD', 0x1D:'FEATURE'}
FIELDS=['index','end_us','end_sck','command','status','direction','register','data_hex',
        'MOSI_hex','MISO_hex','note']

def decode_frame(index, stamp, mosi, miso):
    if len(mosi)!=len(miso):
        raise ValueError(f'Frame {index}: MOSI/MISO lengths differ')
    r=dict.fromkeys(FIELDS,'')
    r.update(index=index,end_us=stamp,MOSI_hex=mosi.hex().upper(),
             MISO_hex=miso.hex().upper())
    if not mosi:
        r.update(command='EMPTY',note='CSN pulse without a complete byte')
        return r
    op=mosi[0]
    r['status']=f'{miso[0]:02X}'
    data=b''
    if 0x00<=op<=0x1F:
        r.update(command='R_REGISTER',direction='radio_to_robot',
                 register=REG.get(op,f'0x{op:02X}')); data=miso[1:]
    elif 0x20<=op<=0x3F:
        reg=op&0x1F
        r.update(command='W_REGISTER',direction='robot_to_radio',
                 register=REG.get(reg,f'0x{reg:02X}')); data=mosi[1:]
        if reg==5 and data: r['note']=f'RF_CH={data[0]}; nominal MHz={2400+data[0]}'
    elif op==0x61:
        r.update(command='R_RX_PAYLOAD',direction='radio_to_robot'); data=miso[1:]
    elif op in (0xA0,0xB0):
        r.update(command='W_TX_PAYLOAD' if op==0xA0 else 'W_TX_PAYLOAD_NOACK',
                 direction='robot_to_radio'); data=mosi[1:]
    elif 0xA8<=op<=0xAD:
        r.update(command='W_ACK_PAYLOAD',direction='robot_to_radio',
                 note=f'pipe={op&7}'); data=mosi[1:]
    elif op==0x60:
        r.update(command='R_RX_PL_WID',direction='radio_to_robot'); data=miso[1:]
    elif op==0x50:
        r.update(command='ACTIVATE',direction='robot_to_radio'); data=mosi[1:]
    else:
        r['command']={0xE1:'FLUSH_TX',0xE2:'FLUSH_RX',0xE3:'REUSE_TX_PL',
                      0xFF:'NOP'}.get(op,f'UNKNOWN_0x{op:02X}')
    r['data_hex']=data.hex().upper()
    if len(mosi)>33:
        r['note']+='; more than 33 bytes: check framing/protocol'
    if 'PAYLOAD' in r['command'] and not 1<=len(data)<=32:
        r['note']+='; invalid nRF24 payload length'
    return r

def parse_ce_capture(text, allow_partial=False):
    """Return (metadata, SPI frames, CE events). Legacy v1-3 has no CE events.

    CE timestamps and SPI end timestamps use the same TIM5 epoch on the
    recording MCU; both have interrupt-entry timing jitter.
    """
    lines=text.splitlines()
    begin=[i for i,line in enumerate(lines) if line.startswith('#BEGIN ')]
    if len(begin)!=1: raise ValueError('Expected exactly one #BEGIN capture')
    start=begin[0]
    end=next((i for i in range(start+1,len(lines)) if lines[i].strip()=='#END'),None)
    if end is None: raise ValueError('Missing #END: UART export is incomplete')
    meta=dict(re.findall(r'(\w+)=([^\s]+)',lines[start]))
    version=meta.get('version')
    if version not in ('1','2','3','4'): raise ValueError('Unsupported capture version')
    if version=='2' and meta.get('timestamps')!='none':
        raise ValueError('v2 capture must explicitly declare timestamps=none')
    if version in ('3','4') and meta.get('timestamps')!='exti3_tim5_us':
        raise ValueError('Unknown CSN timestamp source')
    if version=='4' and meta.get('ce_source')!='pe5_exti_tim5_us':
        raise ValueError('Unknown CE capture source')
    flags=int(meta.get('flags','-1'),0)
    if flags and not allow_partial:
        raise ValueError(f'Capture flags={flags:#x}; see README. '
                         'Use --allow-partial only to inspect an incomplete capture.')
    result=[]
    ce=[]
    total=0
    prev_us=-1
    prev_ce=-1
    prev_level=int(meta['ce_start']) if version=='4' else None
    for line in lines[start+1:end]:
        if line.startswith('F,'):
            cells=line.split(',')
            if len(cells)!=(6 if version in ('3','4') else 5):
                raise ValueError('Malformed frame line')
            if version in ('3','4'):
                _,i,t,us,mosi_hex,miso_hex=cells
                if not us: raise ValueError(f'Missing timestamp for frame {i}')
                stamp=int(us)
                if stamp<prev_us: raise ValueError('Nonmonotonic SPI timestamps')
                prev_us=stamp
            else:
                _,i,t,mosi_hex,miso_hex=cells
                stamp=int(t) if version=='1' else ''
            if int(i)!=len(result): raise ValueError('Missing or reordered frame')
            mosi,miso=bytes.fromhex(mosi_hex),bytes.fromhex(miso_hex)
            total+=len(mosi)
            row=decode_frame(int(i),stamp,mosi,miso)
            if version in ('2','3','4'):
                if int(t)!=total*8:
                    raise ValueError('SCK boundary count disagrees with byte data')
                row['end_sck']=int(t)
            result.append(row)
        elif line.startswith('C,'):
            if version!='4': raise ValueError('CE event in old format')
            cells=line.split(',')
            if len(cells)!=4: raise ValueError('Malformed CE event')
            _,i,us,level=cells
            if int(i)!=len(ce): raise ValueError('Missing or reordered CE event')
            t=int(us)
            value=int(level)
            if value not in (0,1) or t<0: raise ValueError('Invalid CE event')
            if t<prev_ce: raise ValueError('Nonmonotonic CE timestamps')
            # Duplicates are retained only for explicit partial/error inspection.
            if value==prev_level and not allow_partial:
                raise ValueError('Repeated CE level: possible missed edge')
            prev_level=value
            prev_ce=t
            ce.append({'index':int(i),'t_us':t,'level':value,
                       'edge':'rising' if value else 'falling'})
    if version in ('3','4') and int(meta['raw_times'])!=int(meta['frames']):
        raise ValueError('Different time and frame counts (read flags)')
    if len(result)!=int(meta['frames']) or total!=int(meta['complete_bytes']):
        raise ValueError('Header counts disagree with received SPI data')
    if version=='4':
        if len(ce)!=int(meta['ce_count']):
            raise ValueError('Header CE count disagrees with CE data')
        if int(meta['ce_end']) not in (0,1) or int(meta['ce_start']) not in (0,1):
            raise ValueError('Invalid CE start/end level')
        if not flags and ce and ce[-1]['level']!=int(meta['ce_end']):
            raise ValueError('CE final level disagrees with recorded edges')
    return meta,result,ce


def parse_capture(text, allow_partial=False):
    """Legacy API: return metadata, SPI frames. For CE use parse_ce_capture."""
    meta,rows,_=parse_ce_capture(text,allow_partial)
    return meta,rows


def build_timeline(spi_frames,ce_events):
    """Sorted common-time-base timeline, with SPI frames timed at CSN rising."""
    result=[]
    for row in spi_frames:
        t=row['end_us']
        if not isinstance(t,int): continue
        reg=row['register'] or ''
        status_reg=None
        if row['command']=='R_REGISTER' and reg=='STATUS' and len(row['data_hex'])>=2:
            status_reg=int(row['data_hex'][:2],16)
        # MISO[0] is the SPI status returned during all commands, but sticky.
        if status_reg is not None:
            bits=[]
            if status_reg & 0x20: bits.append('TX_DS')
            if status_reg & 0x10: bits.append('MAX_RT')
            if status_reg & 0x40: bits.append('RX_DR')
            note=f'READ_STATUS=0x{status_reg:02X}' + (' ['+'+'.join(bits)+']' if bits else '')
        elif row['command']=='W_TX_PAYLOAD':
            note=f'TX_PAYLOAD len={len(row["data_hex"])//2}'
        elif row['command']=='W_REGISTER' and reg=='STATUS':
            note='CLEAR_STATUS='+row['data_hex']
        else:
            note=''
        result.append({'t_us':t,'type':'SPI','index':row['index'],
                       'level':'','event':row['command'],
                       'register':reg,'detail':note,
                       'MOSI_hex':row['MOSI_hex'],'MISO_hex':row['MISO_hex']})
    for row in ce_events:
        result.append({'t_us':row['t_us'],'type':'CE','index':row['index'],
                       'level':row['level'],'event':row['edge'],
                       'register':'','detail':'','MOSI_hex':'','MISO_hex':''})
    result.sort(key=lambda r:(r['t_us'],0 if r['type']=='CE' else 1,r['index']))
    return result

def record(port, output, seconds):
    try: import serial
    except ImportError: raise SystemExit('Install pyserial: python -m pip install pyserial')
    with serial.Serial(port,115200,timeout=0.2,write_timeout=2) as dev:
        time.sleep(0.2)
        dev.reset_input_buffer()
        host_request=time.time()
        dev.write(b'a'); dev.flush()
        deadline=time.monotonic()+seconds
        buf=bytearray()
        print('Capture started; waiting for UART export (control should already be positioned)...')
        while time.monotonic()<deadline:
            buf.extend(dev.read(max(1,dev.in_waiting)))
            if b'#END\r\n' in buf or b'#END\n' in buf:
                # Host time is approximate, never treated as synchronized time.
                from datetime import datetime, timezone
                host_time=datetime.fromtimestamp(host_request, timezone.utc).isoformat()
                Path(output).write_bytes((f'#host_request_utc={host_time} (approximate, not synchronized)\n').encode('ascii')+buf)
                print(f'Saved {output} ({len(buf)} bytes)')
                return
        partial=str(output)+'.partial'
        from datetime import datetime, timezone
        host_time=datetime.fromtimestamp(host_request, timezone.utc).isoformat()
        Path(partial).write_bytes((f'#host_request_utc={host_time} (approximate, not synchronized)\n').encode('ascii')+buf)
        raise SystemExit(f'Timeout; incomplete bytes saved in {partial}')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='action',required=True)
    r=sub.add_parser('record');r.add_argument('--port',required=True)
    r.add_argument('--out',default='capture.txt');r.add_argument('--timeout',type=float,default=60)
    d=sub.add_parser('decode');d.add_argument('input');d.add_argument('--out',default='decoded.csv')
    d.add_argument('--ce-out',help='CE CSV path (v4 only; default: <out>_ce.csv)')
    d.add_argument('--timeline-out',help='Merged timeline CSV (default: <out>_timeline.csv)')
    d.add_argument('--allow-partial',action='store_true')
    a=p.parse_args()
    if a.action=='record': record(a.port,a.out,a.timeout);return
    meta,rows,ce=parse_ce_capture(Path(a.input).read_text(encoding='ascii'),a.allow_partial)
    with open(a.out,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
    print(f"{len(rows)} frames; stop={meta['reason']}; flags={meta['flags']}; {a.out}")
    if meta['version']=='4':
        base=Path(a.out)
        ce_out=Path(a.ce_out) if a.ce_out else base.with_name(base.stem+'_ce.csv')
        timeline_out=(Path(a.timeline_out) if a.timeline_out else
                      base.with_name(base.stem+'_timeline.csv'))
        with ce_out.open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=['index','t_us','level','edge'])
            w.writeheader();w.writerows(ce)
        timeline=build_timeline(rows,ce)
        with timeline_out.open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=['t_us','type','index','level','event',
                                           'register','detail','MOSI_hex','MISO_hex'])
            w.writeheader();w.writerows(timeline)
        print(f"{len(ce)} CE edges; first level={meta['ce_start']}; "
              f"end level={meta['ce_end']}; ce_overflow={meta['ce_overflow']}")
        print(f'CE events: {ce_out}; merged TIM5 timeline: {timeline_out}')
    print('R_RX_PAYLOAD: incoming payload; W_TX_PAYLOAD: outgoing payload, excluding STATUS/opcode.')
    print('Legacy direction labels use robot to mean the controller at the probe location (remote or robot).')
    print('IRQ timestamps are software EXTI timestamps, not hardware-edge capture.')

if __name__=='__main__':
    try: main()
    except (ValueError,OSError) as e:
        print(f'Error: {e}',file=sys.stderr);sys.exit(1)
