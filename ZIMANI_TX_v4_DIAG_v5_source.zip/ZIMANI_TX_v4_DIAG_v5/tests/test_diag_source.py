import pathlib
import re
import unittest
ROOT = pathlib.Path(__file__).resolve().parents[1]

class DiagnosticSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.s = (ROOT/'Core/Src/main.c').read_text()
        cls.config = (ROOT/'Core/Inc/zimani_config.h').read_text()
    def test_default_stop_only(self):
        self.assertRegex(self.config, r'#define ZIMANI_DIAG_STOP_ONLY\s+1u')
        self.assertIn('if(ZIMANI_DIAG_STOP_ONLY) z_stop(&control,FAULT_STOP);', self.s)
    def test_protocol_preserved(self):
        for x in ('ZIMANI_RADIO_ADDRESS', 'RADIO_RETRIES', 'RADIO_CHANNEL', 'RADIO_RF_SETUP'):
            self.assertIn(x,self.s)
        self.assertIn('write_many(0xA0,payload,26);',self.s)
        self.assertIn('write_reg(0,0x0A);',self.s)
        self.assertIn('write_reg(0,0x0B);',self.s)
    def test_events(self):
        for event in ('INIT','TX','DONE','RX','BAD_WIDTH','STAT'):
            self.assertIn(f'diag_prefix("{event}"',self.s)
        for field in ('" arc="','" plos="','" st="','" rxdr="','" fifo="'):
            self.assertIn(field,self.s)
    def test_ce_hold_inherited(self):
        self.assertIn('tx_started=now_us();ce(1);',self.s)
        self.assertNotIn('ce(0);radio_state=2;',self.s)
    def test_uart_baud(self):
        self.assertIn('ZIMANI_DIAG_BAUD 230400u', self.config)
        self.assertIn('USART3->BRR=(42000000u+(ZIMANI_DIAG_BAUD/2u))/ZIMANI_DIAG_BAUD;',self.s)

    def test_queue_overflow_is_counted(self):
        self.assertIn('uart_dropped_lines++',self.s)
        self.assertIn('" uart_drop="',self.s)

if __name__=='__main__':unittest.main()
