"""Static source-safety and log-parser checks. Not a replacement for target tests."""
from pathlib import Path
import importlib.util
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'Core/Src/main.c').read_text()
CONF = (ROOT / 'Core/Inc/zimani_config.h').read_text()


class FirmwareChecks(unittest.TestCase):
    def test_stop_only(self):
        self.assertIn('ZIMANI_DIAG_STOP_ONLY 1u', CONF)
        self.assertIn('z_stop(&control,FAULT_STOP)', SRC)
        self.assertNotIn('z_accept(&control', SRC)
        self.assertIn('#error ZIMANI_TX_v7 requires', SRC)

    def test_radio_manual_only_and_bounded(self):
        p = SRC.index('static void radio_service(void)\n{')
        self.assertLess(SRC.index('if(!test_active) return;',p), SRC.index('write_many(0xA0,payload,26);',p))
        self.assertIn('TEST_MAX_FRAMES 20u', SRC)
        self.assertIn('TEST_MAX_DURATION_US 6000000u', SRC)
        self.assertIn('finish_test("DEADLINE")', SRC)
        self.assertIn('finish_test("COUNT_REACHED")', SRC)
        self.assertIn('finish_test("BUTTON")', SRC)
        self.assertIn('cli_equal(cli_line,"CANCEL")',SRC)
        self.assertIn('cli_equal(cli_line,"STATUS")',SRC)
        self.assertIn('if(test_active||pending_count)', SRC)

    def test_recovery_only_after_first_maxrt(self):
        p=SRC.index('} else if(st&0x10u) {')
        q=SRC.index('} else if(elapsed>=RADIO_TX_TIMEOUT_US)',p)
        branch=SRC[p:q]
        self.assertIn('if(tx_round==1u)',branch)
        self.assertIn('if(fifo_before&0x10u)',branch)
        self.assertIn('write_reg(7u,0x10u);',branch)
        self.assertIn('tx_round=2u;',branch)
        self.assertIn('pulse_end=round_started+20u;',branch)
        self.assertIn('ce(1);',branch)
        self.assertIn('radio_cmd(0xE1);',branch.split('} else {',1)[1])
        self.assertNotIn('write_many(0xA0',branch)
        self.assertEqual(branch.count('recovery_count++'),1)

    def test_no_recovery_after_timeout(self):
        p=SRC.index('} else if(elapsed>=RADIO_TX_TIMEOUT_US)')
        q=SRC.index('} else if(radio_state==3u)',p)
        branch=SRC[p:q]
        self.assertNotIn('ce(1)', branch)
        self.assertIn('radio_cmd(0xE1)',branch)

    def test_pulse_low_both_rounds(self):
        self.assertIn('ce(0); /* v7: one short pulse per hardware transmission round. */',SRC)
        self.assertIn('tx_round=1u;',SRC)
        self.assertIn('tx_round=2u;',SRC)

    def test_rf_and_time_parameters(self):
        for value in ('RADIO_TX_TIMEOUT_US 35000u','RADIO_RETRIES 0xF3u',
                      'RADIO_CHANNEL 0x45u','RADIO_RF_SETUP 0x23u',
                      'ZIMANI_DIAG_BAUD 230400u'):
            self.assertIn(value,CONF)

    def test_end_is_powerdown(self):
        self.assertIn('write_reg(0,0x08); /* RF power-down',SRC)
        self.assertIn('ce(0);test_radio_ready=0u;',SRC)

    def test_rounds_and_end_logging(self):
        for log in ('"ROUND"','"RETRY"','"DONE"','"END"','"SNAP"','"BEGIN"'):
            self.assertIn(log,SRC)
        self.assertIn('append(" recovery_max=1 attempts_max=2',SRC)
        self.assertIn('append(" recovered_acks=")',SRC)


class LogParserChecks(unittest.TestCase):
    def test_recovered_ack(self):
        path=ROOT/'pc/summarize_v7.py'
        spec=importlib.util.spec_from_file_location('summarize_v7',path)
        mod=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        rows=[
          'D TX us=1 id=1 pay=ABC',
          'D ROUND us=20 id=1 attempt=1 r=MAX_RT dt=21000',
          'D RETRY us=21 id=1 attempt=2 reused_fifo=1',
          'D ROUND us=35 id=1 attempt=2 r=TX_DS dt=14000',
          'D DONE us=35 id=1 r=TX_DS attempts=2 recovered=1',
          'D END us=55 id=1 sent=1 target=1 recovered_acks=1'
        ]
        r=mod.parse(rows)
        self.assertEqual(r['events']['RETRY'],1)
        self.assertEqual(r['rounds'][('1','MAX_RT')],1)
        self.assertEqual(r['rounds'][('2','TX_DS')],1)
        self.assertEqual(r['logical']['TX_DS'],1)
        self.assertEqual(r['tx']-r['done'],set())


if __name__=='__main__': unittest.main()
