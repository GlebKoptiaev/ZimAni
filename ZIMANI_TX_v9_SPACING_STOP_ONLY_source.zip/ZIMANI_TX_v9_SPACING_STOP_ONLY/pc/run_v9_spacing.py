#!/usr/bin/env python3
"""UART capture for v9 STOP-only spacing experiment.

No transmission when --count is 0. A bounded TEST or FAST command is sent
only when BOTH --count 1..20 and --confirm-radio-tx are present.
"""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import time


def utc_stamp():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--port', required=True, help='TX NUCLEO serial port, not OEM SPI analyzer')
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--baud', type=int, default=230400)
    p.add_argument('--seconds', type=float, default=8.0)
    p.add_argument('--count', type=int, default=0, help='0 = idle-only; 1..20 = bounded STOP')
    p.add_argument('--profile', choices=('base','fast'), default='base',
                   help='base=80ms post-RX pause; fast=5ms post-RX pause')
    p.add_argument('--confirm-radio-tx', action='store_true',
                   help='Required to send TEST/FAST command for physical RF TX')
    p.add_argument('--start-delay', type=float, default=1.0)
    a = p.parse_args()
    if not 0 <= a.count <= 20:
        p.error('--count must be 0..20')
    if a.count and not a.confirm_radio_tx:
        p.error('RF TX requires explicit --confirm-radio-tx')
    if a.count == 0 and a.profile != 'base':
        p.error('profile=fast requires --count >0 and --confirm-radio-tx')
    if a.seconds <= 0 or a.start_delay < 0 or (a.count and a.start_delay >= a.seconds):
        p.error('invalid --seconds or --start-delay')
    try:
        import serial
    except ImportError as exc:
        raise SystemExit('Install pyserial: py -m pip install pyserial') from exc

    a.out.parent.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    deadline = started + a.seconds
    command = (f'FAST {a.count}' if a.profile == 'fast' else f'TEST {a.count}')
    sent = False
    lines = 0
    with serial.Serial(a.port, a.baud, timeout=0.10, write_timeout=1.0) as ser, \
         a.out.open('w', encoding='utf-8', newline='\n') as log:
        log.write(f'#host_start={utc_stamp()}\n')
        log.write(f'#source=ZIMANI_TX_v9_SPACING port={a.port} baud={a.baud} count={a.count} profile={a.profile}\n')
        ser.write(b'STATUS\r\n')  # Query only; no TX.
        try:
            while time.monotonic() < deadline:
                if a.count and not sent and time.monotonic()-started >= a.start_delay:
                    ser.write((command+'\r\n').encode('ascii'))
                    log.write(f'#host_command={utc_stamp()} {command}\n')
                    print(f'Sent {command}: bounded hard-coded STOP only (not robot motion).')
                    sent = True
                raw=ser.readline(2048)
                if not raw:
                    continue
                line=raw.decode('utf-8', errors='replace').rstrip('\r\n')
                stamped=f'{utc_stamp()} {line}'
                log.write(stamped+'\n')
                lines+=1
                if line.startswith(('D INIT','D CMD','D BEGIN','D END','D STAT','D IDLE','D BAD_WIDTH')):
                    print(stamped)
        except KeyboardInterrupt:
            print('Capture interrupted by user.')
        finally:
            if a.count:
                try:
                    ser.write(b'CANCEL\r\n')
                except (serial.SerialException,serial.SerialTimeoutException):
                    pass
            log.write(f'#host_stop={utc_stamp()} records={lines}\n')
            log.flush()
    print(f'Saved {lines} UART lines to {a.out}')


if __name__=='__main__':
    main()
