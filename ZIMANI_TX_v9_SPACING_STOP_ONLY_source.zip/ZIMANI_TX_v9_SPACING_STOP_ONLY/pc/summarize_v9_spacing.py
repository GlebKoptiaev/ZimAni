#!/usr/bin/env python3
"""Offline comparison: extract D BEGIN/END and real D TX-to-TX intervals. No serial/RF."""
import argparse
from pathlib import Path
import re
import statistics


def analyze(path):
    lines=path.read_text(encoding='utf-8',errors='replace').splitlines()
    tx=[];begin=[];end=[];retries=0
    for line in lines:
        m=re.search(r'(?:^|\s)D\s+(BEGIN|END|TX|RETRY)\s+(.*)',line)
        if not m: continue
        event,tail=m.groups()
        d=dict(re.findall(r'([a-z_]+)=([^\s]+)',tail))
        if event=='TX' and 'us' in d:
            tx.append(int(d['us']))
        if event=='BEGIN': begin.append(d)
        if event=='END': end.append(d)
        if event=='RETRY': retries+=1
    intervals=[(b-a) % (1<<32) for a,b in zip(tx,tx[1:])]
    return {'file':path,'begin':begin,'end':end,'tx':tx,'intervals':intervals,'retries':retries}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('files',nargs='+',type=Path)
    a=p.parse_args()
    for f in a.files:
        r=analyze(f)
        print('\nFile:',f)
        print('BEGIN:',r['begin'])
        print('END:',r['end'])
        print('TX count:',len(r['tx']),'RETRY observations:',r['retries'])
        if r['intervals']:
            vals=r['intervals']
            print('Actual TX→TX intervals ms:',[round(x/1000,3) for x in vals])
            print('Median:',round(statistics.median(vals)/1000,3),'ms; mean:',round(statistics.mean(vals)/1000,3),'ms')
        elif r['tx']:
            print('No pair of TX events to calculate an interval')
        else:
            print('No RF TX seen in this capture')
        if r['tx'] and not r['end']:
            print('WARNING: capture lacks D END; check active=0,ce=0,radio=0')


if __name__=='__main__': main()
