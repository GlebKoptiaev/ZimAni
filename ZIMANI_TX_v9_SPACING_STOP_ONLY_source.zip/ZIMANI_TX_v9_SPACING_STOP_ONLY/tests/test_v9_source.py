"""Host-only regression checks for bounded STOP-only v9 spacing experiment."""
from pathlib import Path
import importlib.util
import unittest

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'Core/Src/main.c').read_text(encoding='utf-8')
CONF=(ROOT/'Core/Inc/zimani_config.h').read_text(encoding='utf-8')
CONTROL=(ROOT/'Core/Src/zimani_control.c').read_text(encoding='utf-8')
RUNNER=(ROOT/'pc/run_v9_spacing.py').read_text(encoding='utf-8')

class SourceCheck(unittest.TestCase):
    def test_payload_stop_only(self):
        self.assertIn('#define ZIMANI_DIAG_STOP_ONLY 1u',CONF)
        self.assertIn('#error ZIMANI_TX_v9 requires ZIMANI_DIAG_STOP_ONLY',MAIN)
        self.assertIn('z_stop(&control,FAULT_STOP)',MAIN)
        self.assertNotIn('z_accept(&control',MAIN)
        self.assertIn('ZIMANI_HEADER_BYTES',CONTROL)
        self.assertIn('FAULT_STOP',CONTROL)
        self.assertNotIn('W_TX_PAYLOAD_NO_ACK',MAIN)

    def test_only_spacing_varies(self):
        self.assertIn('#define TEST_SPACING_BASE_US 80000u',MAIN)
        self.assertIn('#define TEST_SPACING_FAST_US 5000u',MAIN)
        self.assertIn('test_spacing_us=pending_fast?TEST_SPACING_FAST_US:TEST_SPACING_BASE_US;',MAIN)
        self.assertIn('next_tx=now_us()+test_spacing_us;',MAIN)
        for marker in ('RADIO_CHANNEL 0x45u','RADIO_RF_SETUP 0x23u',
                       'RADIO_RETRIES 0xF3u','RADIO_TX_TIMEOUT_US 35000u'):
            self.assertIn(marker,CONF)
        self.assertIn('#define TEST_RX_WINDOW_US 10000u',MAIN)

    def test_manual_bounds_and_shutdown(self):
        a=MAIN.index('static void radio_service(void)\n{')
        self.assertLess(MAIN.index('if(!test_active) {ce(0);return;}',a),
                        MAIN.index('write_many(0xA0,payload,26);',a))
        for marker in ('#define TEST_MAX_FRAMES 20u','#define TEST_MAX_DURATION_US 6000000u',
                       'finish_test("DEADLINE")','finish_test("BUTTON")','finish_test("COUNT_REACHED")',
                       'cli_equal(cli_line,"CANCEL")','if(test_active||pending_count)',
                       'write_reg(0,0x08); /* RF power-down'):
            self.assertIn(marker,MAIN)
        self.assertIn('else {pending_count=(uint16_t)val;pending_fast=fast;}',MAIN)
        self.assertIn('pending_cancel=0u;pending_count=0u;pending_fast=0u;',MAIN)

    def test_ce_hold_logic_preserved(self):
        a=MAIN.index('if(radio_state==1u && due(t,pulse_end))')
        b=MAIN.index('if(radio_state==2u && due(t,next_poll))',a)
        self.assertNotIn('ce(0)',MAIN[a:b])
        a=MAIN.index('} else if(st&0x10u) {')
        b=MAIN.index('} else if(elapsed>=RADIO_TX_TIMEOUT_US)',a)
        first=MAIN[a:b].split('} else {',1)[0]
        self.assertIn('write_reg(7u,0x10u);',first)
        self.assertIn('tx_round=2u;',first)
        self.assertNotIn('ce(1);',first)
        self.assertNotIn('ce(0);',first)
        self.assertNotIn('write_many(0xA0',first)

    def test_log_profile_and_actual_time(self):
        for marker in ('append(" profile=")','append(" spacing_us=");number(test_spacing_us);',
                       'diag_tx_event(tx_started,++diag_tx_id,payload);','append(" duration_us=")',
                       'diag_prefix("END",now_us(),diag_tx_id)'):
            self.assertIn(marker,MAIN)

    def test_host_explicit_confirmation(self):
        self.assertIn('--confirm-radio-tx',RUNNER)
        self.assertIn('if a.count and not a.confirm_radio_tx:',RUNNER)
        self.assertIn("'FAST {a.count}'",RUNNER)
        self.assertIn("'TEST {a.count}'",RUNNER)
        self.assertIn("ser.write(b'CANCEL\\r\\n')",RUNNER)
        self.assertIn('if a.count:',RUNNER)

class ParseCheck(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec=importlib.util.spec_from_file_location('analyze',ROOT/'pc/summarize_v9_spacing.py')
        cls.m=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.m)

    def test_existing_log_period(self):
        prior=Path('/mnt/data/stm_v7_control.txt')
        if prior.exists():
            r=self.m.analyze(prior)
            self.assertEqual(len(r['tx']),10)
            import statistics
            self.assertEqual(statistics.median(r['intervals']),132800)

    def test_synthetic_profile_summary(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'capture.txt'
            p.write_text('D BEGIN us=1 id=2 profile=FAST spacing_us=5000\n'
                         'D TX us=100 id=3 ce=1\nD TX us=59100 id=4 ce=1\n'
                         'D END us=60000 id=4 sent=2 target=2 ack=1 fail=1 ce=0 radio=0 spacing_us=5000\n')
            r=self.m.analyze(p)
            self.assertEqual(r['intervals'],[59000])
            self.assertEqual(r['begin'][0]['profile'],'FAST')
            self.assertEqual(r['end'][0]['ce'],'0')

if __name__=='__main__':unittest.main()
