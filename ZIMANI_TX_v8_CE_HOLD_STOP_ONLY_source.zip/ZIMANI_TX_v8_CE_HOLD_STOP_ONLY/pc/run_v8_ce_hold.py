#!/usr/bin/env python3
"""Record ZIMANI v8 CE-HOLD MAX_RT-probe UART diagnostics; transmit only with explicit --confirm-radio-tx.

Idle example:
  py run_v8_ce_hold.py --port COM9 --out tx_v8_idle_cold.txt --seconds 5
Manual STOP-only test (max 20 logical packets, <=2 MAX_RT observations each):
  py run_v8_ce_hold.py --port COM9 --out tx_v8_test10.txt --count 10 --confirm-radio-tx --seconds 8
"""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import time


def utc_stamp():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds')


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--port', required=True, help='Port of TX NUCLEO (not RF listener)')
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--baud', type=int, default=230400)
    p.add_argument('--seconds', type=float, default=8.0, help='Total capture time (default 8 s)')
    p.add_argument('--count', type=int, default=0, help='0=IDLE, 1..20=bounded STOP-only frames')
    p.add_argument('--confirm-radio-tx', action='store_true',
                   help='Explicit confirmation needed to transmit the bounded STOP-only test')
    p.add_argument('--start-delay', type=float, default=1.0, help='Idle observation before TEST')
    a = p.parse_args()
    if not 0 <= a.count <= 20:
        p.error('--count must be 0..20')
    if a.count and not a.confirm_radio_tx:
        p.error('To initiate RF transmissions add --confirm-radio-tx')
    if a.seconds <= 0 or a.start_delay < 0 or (a.count and a.start_delay >= a.seconds):
        p.error('Invalid --seconds/--start-delay')
    try:
        import serial
    except ImportError as exc:
        raise SystemExit('Install pyserial: py -m pip install pyserial') from exc

    a.out.parent.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    deadline = started + a.seconds
    sent = False
    count_lines = 0
    with serial.Serial(a.port, a.baud, timeout=0.10, write_timeout=1.0) as ser, \
         a.out.open('w', encoding='utf-8', newline='\n') as log:
        log.write(f'#host_start={utc_stamp()}\n')
        log.write(f'#source=ZIMANI_TX_v8_CE_HOLD port={a.port} baud={a.baud} count={a.count}\n')
        ser.write(b'STATUS\r\n')  # Query only; never initiates TX.
        print('Listening. Default is IDLE, no RF transmissions.')
        try:
            while time.monotonic() < deadline:
                if a.count and not sent and time.monotonic() - started >= a.start_delay:
                    command = f'TEST {a.count}\r\n'.encode('ascii')
                    ser.write(command)
                    log.write(f'#host_command={utc_stamp()} TEST {a.count}\n')
                    print(f'Explicitly requested {a.count} STOP-only logical packets (up to {2*a.count} bounded PTX observation windows; actual retry on CE hold is unproven).')
                    sent = True
                raw = ser.readline(2048)
                if not raw:
                    continue
                line = raw.decode('utf-8', errors='replace').rstrip('\r\n')
                stamped = f'{utc_stamp()} {line}'
                log.write(stamped + '\n')
                count_lines += 1
                if line.startswith(('D INIT', 'D CMD', 'D IDLE', 'D BEGIN', 'D END', 'D STAT', 'D BAD_WIDTH')):
                    print(stamped)
        except KeyboardInterrupt:
            print('Cancelled by user')
        finally:
            # The MCU's hard count/deadline remain in force even if USB disappears.
            if a.count:
                try:
                    ser.write(b'CANCEL\r\n')
                except (serial.SerialException, serial.SerialTimeoutException):
                    pass
            log.write(f'#host_stop={utc_stamp()} records={count_lines}\n')
            log.flush()
    print(f'Saved {count_lines} UART lines to: {a.out}')


if __name__ == '__main__':
    main()
