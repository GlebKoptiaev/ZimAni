#!/usr/bin/env python3
r"""Read-only summary of ZIMANI TX v8 bounded CE-HOLD recovery UART captures.

Usage: py .\summarize_v8.py .\tx_v8_test10.txt
No serial-port access and absolutely no RF control in this utility.
"""
import argparse
from collections import Counter, defaultdict
from pathlib import Path
import re


def parse(lines):
    event_counts = Counter()
    logical_results = Counter()
    round_results = Counter()
    attempts = defaultdict(list)
    tx = set()
    done = set()
    retries = set()
    hold_events = []
    received = Counter()
    ends = []
    for line in lines:
        match = re.search(r'(?:^|\s)D\s+(\w+)\s+(.*)', line)
        if not match:
            continue
        event, tail = match.groups()
        fields = dict(re.findall(r'([a-z_]+)=([^\s]+)', tail))
        event_counts[event] += 1
        txid = fields.get('id', '?')
        if event == 'TX':
            tx.add(txid)
        elif event == 'ROUND':
            round_results[(fields.get('attempt', '?'), fields.get('r', '?'))] += 1
            attempts[txid].append(fields)
        elif event == 'RETRY':
            retries.add(txid)
            hold_events.append(fields)
        elif event == 'DONE':
            done.add(txid)
            logical_results[fields.get('r', '?')] += 1
        elif event == 'RX':
            received[fields.get('ok', '?')] += 1
        elif event == 'END':
            ends.append(fields)
    return {
        'events':event_counts,
        'logical':logical_results,
        'rounds':round_results,
        'attempts':dict(attempts),
        'tx':tx,'done':done,'retries':retries,'hold_events':hold_events,'received':received,'ends':ends
    }


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('file', type=Path)
    a=p.parse_args()
    r=parse(a.file.read_text(encoding='utf-8', errors='replace').splitlines())
    print('File:', a.file)
    print('Events:', dict(r['events']))
    print('Logical STOP results:', dict(r['logical']))
    print('Hardware rounds (attempt, result):', dict(r['rounds']))
    print('CE-HOLD retry observation requests:', len(r['retries']))
    print('CE held (software-intent log):', sum(1 for x in r['hold_events'] if x.get('mode') == 'CE_HOLD' and x.get('no_ce_edge') == '1'))
    print('TIMEOUT rounds after CE hold:', r['rounds'].get(('2','TIMEOUT'),0))
    print('RX valid/invalid:', dict(r['received']))
    print('TX IDs without DONE:', sorted(r['tx']-r['done']))
    print('Recovered ACKs (first MAX_RT then TX_DS):')
    recovered = 0
    for txid, seq in r['attempts'].items():
        if len(seq)==2 and seq[0].get('r')=='MAX_RT' and seq[1].get('r')=='TX_DS':
            recovered += 1
            print('  id',txid,'rounds:',[(s.get('attempt'),s.get('r'),s.get('dt')) for s in seq])
        elif len(seq)>2:
            print('WARNING unexpected >2 rounds for id',txid)
    print('Recovered ACK count:',recovered)
    print('NOTE: CE-HOLD can yield TIMEOUT: no new hardware transmission is guaranteed.')
    for fields in r['ends']:
        print('Run END:', fields)
    if not r['events']['BEGIN'] and not r['events']['TX']:
        print('Idle-only log: no transmissions seen. Confirm D CMD active=0 ce=0.')
    if r['events']['TX'] and not r['events']['END']:
        print('WARNING: D END missing; possible partial capture, check status and CE.')


if __name__=='__main__': main()
