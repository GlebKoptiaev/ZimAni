/* Host-only payload regression check, no STM32 peripherals and no RF. */
#include <stdio.h>
#include <string.h>
#include "zimani_control.h"
int main(void)
{
 ZControl c;
 uint8_t data[26];
 static const uint8_t expected[26] = {
 0xAA,0xF8,0xC4,0x20,0x00,0x43,0x4E,0x1D,
 0x04,0x02,0x00,0x00,0x00,0x00,0x64,0x00,
 0x00,0x00,0x00,0x00,0x00,0x01,0x00,0x01,
 0xA0,0xED};
 z_init(&c);
 z_stop(&c,FAULT_STOP);
 z_payload(&c.command,data);
 if (memcmp(data,expected,sizeof(expected))!=0) {
   fprintf(stderr,"STOP payload mismatch\n");return 1;
 }
 if(c.armed||c.can_arm||c.command.forward||c.command.turn||c.command.blade||!c.command.estop) {
   fprintf(stderr,"STOP safety state mismatch\n");return 2;
 }
 puts("PASS: fixed 26-byte STOP payload and safe state");
 return 0;
}
