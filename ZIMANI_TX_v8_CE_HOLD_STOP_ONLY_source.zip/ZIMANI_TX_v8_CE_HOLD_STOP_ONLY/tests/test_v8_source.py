"""v8 static safety regression checks; cannot substitute for on-target validation."""
from collections import Counter
from pathlib import Path
import importlib.util
import unittest

ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/'Core/Src/main.c').read_text(encoding='utf-8')
CONF=(ROOT/'Core/Inc/zimani_config.h').read_text(encoding='utf-8')
CTRL=(ROOT/'Core/Src/zimani_control.c').read_text(encoding='utf-8')

class FirmwareChecks(unittest.TestCase):
    def test_hard_stop_only(self):
        self.assertIn('#define ZIMANI_DIAG_STOP_ONLY 1u',CONF)
        self.assertIn('#error ZIMANI_TX_v8 requires',SRC)
        self.assertIn('z_stop(&control,FAULT_STOP)',SRC)
        self.assertNotIn('z_accept(&control',SRC)
        self.assertNotIn('W_TX_PAYLOAD_NO_ACK',SRC)
        self.assertIn('ZIMANI_HEADER_BYTES',CONF)
        self.assertIn('FAULT_STOP', CTRL)

    def test_bounded_manual_start(self):
        p=SRC.index('static void radio_service(void)\n{')
        self.assertLess(SRC.index('if(!test_active) {ce(0);return;}',p),SRC.index('write_many(0xA0,payload,26);',p))
        self.assertIn('#define TEST_MAX_FRAMES 20u',SRC)
        self.assertIn('#define TEST_MAX_DURATION_US 6000000u',SRC)
        for x in ('finish_test("DEADLINE")','finish_test("COUNT_REACHED")','finish_test("BUTTON")',
                  'cli_equal(cli_line,"CANCEL")','cli_equal(cli_line,"STATUS")',
                  'if(test_active||pending_count)'):
            self.assertIn(x,SRC)

    def test_ce_is_kept_high_during_tx_round(self):
        p=SRC.index('if(radio_state==1u && due(t,pulse_end))')
        q=SRC.index('if(radio_state==2u && due(t,next_poll))',p)
        branch=SRC[p:q]
        self.assertNotIn('ce(0)',branch)
        self.assertIn('radio_state=2u;next_poll=t;',branch)
        self.assertIn('ce(1);pulse_end=tx_started+20u;radio_state=1u;',SRC)

    def test_no_ce_edge_when_clearing_first_maxrt(self):
        p=SRC.index('} else if(st&0x10u) {')
        q=SRC.index('} else if(elapsed>=RADIO_TX_TIMEOUT_US)',p)
        branch=SRC[p:q]
        first=branch.split('} else {',1)[0]
        self.assertIn('if(tx_round==1u)',first)
        self.assertIn('if(!ce_high)',first)
        self.assertIn('if(fifo_before&0x10u)',first)
        self.assertIn('write_reg(7u,0x10u);',first)
        self.assertIn('tx_round=2u;',first)
        self.assertIn('radio_state=2u;',first)
        self.assertNotIn('ce(1);',first)
        self.assertNotIn('ce(0);',first)
        self.assertNotIn('write_many(0xA0',first)
        self.assertEqual(branch.count('recovery_count++'),1)
        self.assertIn('ce(0);radio_cmd(0xE1);',branch)

    def test_timeout_never_retries(self):
        p=SRC.index('} else if(elapsed>=RADIO_TX_TIMEOUT_US)')
        q=SRC.index('} else if(radio_state==3u)',p)
        branch=SRC[p:q]
        self.assertNotIn('ce(1)',branch)
        self.assertIn('ce(0);radio_cmd(0xE1);',branch)
        self.assertIn('RADIO_TX_TIMEOUT_US 35000u',CONF)

    def test_radio_config_still_matches_v7(self):
        for key in ('RADIO_RETRIES 0xF3u','RADIO_CHANNEL 0x45u',
                    'RADIO_RF_SETUP 0x23u','ZIMANI_DIAG_BAUD 230400u'):
            self.assertIn(key,CONF)
        self.assertIn('write_reg(0,0x08); /* RF power-down',SRC)
        self.assertIn('ce(0);test_radio_ready=0u;',SRC)

    def test_events_unambiguous(self):
        for ev in ('"TX"','"ROUND"','"RETRY"','"DONE"','"END"','"SNAP"','"BEGIN"'):
            self.assertIn(ev,SRC)
        self.assertIn('mode=CE_HOLD',SRC)
        self.assertIn('no_ce_edge=1',SRC)
        self.assertIn('ce_hold=1 retry_edge=0',SRC)
        self.assertIn('append(" ce=");number(ce_high);',SRC)

class ParserChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec=importlib.util.spec_from_file_location('summarize_v8',ROOT/'pc/summarize_v8.py')
        cls.mod=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.mod)

    def test_hold_ack(self):
        rows=[
          'D TX us=1 id=1 pay=AAA',
          'D ROUND us=20 id=1 attempt=1 ce=1 r=MAX_RT dt=21000',
          'D RETRY us=21 id=1 attempt=2 reused_fifo=1 fresh_payload=0 mode=CE_HOLD ce_before=1 ce_after=1 no_ce_edge=1',
          'D ROUND us=35 id=1 attempt=2 ce=1 r=TX_DS dt=14000',
          'D DONE us=35 id=1 r=TX_DS attempts=2 recovered=1',
          'D END us=55 id=1 sent=1 target=1 recovered_acks=1 ce=0 radio=0',
        ]
        r=self.mod.parse(rows)
        self.assertEqual(r['events']['RETRY'],1)
        self.assertEqual(r['rounds'][('1','MAX_RT')],1)
        self.assertEqual(r['rounds'][('2','TX_DS')],1)
        self.assertEqual(r['logical']['TX_DS'],1)
        self.assertEqual(r['hold_events'][0]['mode'],'CE_HOLD')
        self.assertEqual(r['tx']-r['done'],set())

    def test_hold_timeout_recorded(self):
        r=self.mod.parse(['D ROUND us=41 id=2 attempt=2 ce=1 r=TIMEOUT dt=35000',
                          'D DONE us=42 id=2 r=TIMEOUT attempts=2 recovered=0',
                          'D END us=43 id=2 sent=1 target=1 ce=0 radio=0'])
        self.assertEqual(r['rounds'][('2','TIMEOUT')],1)
        self.assertEqual(r['logical']['TIMEOUT'],1)

if __name__=='__main__': unittest.main()
