/* NUCLEO-F429ZI, ZIMANI transmitter v8 bounded CE-HOLD recovery. NOT the passive recorder.
 * Original OEM remote must be OFF while this board transmits; no OEM wiring to E01.
 * Read README_RU.md before wiring. Core clock 168MHz HSI, SPI3 mode0 ~1.31MHz.
 */
#include "stm32f4xx.h"
#include "zimani_control.h"
#include "zimani_config.h" /* Explicit: CubeIDE may retain an old control.h. */
/* Fail-safe defaults for projects retaining an older zimani_config.h.
 * The full v6 diagnostics configuration is still required for matched
 * radio settings; copy all four Core source/header files as a set. */
#ifndef ZIMANI_DIAG_BAUD
#define ZIMANI_DIAG_BAUD 230400u
#endif
#ifndef ZIMANI_DIAG_STOP_ONLY
#define ZIMANI_DIAG_STOP_ONLY 1u
#endif
#if ZIMANI_DIAG_STOP_ONLY != 1u
#error ZIMANI_TX_v8 requires ZIMANI_DIAG_STOP_ONLY=1 (STOP only)
#endif
#if !defined(STM32F429xx)
#error Select STM32F429xx
#endif
#define RX_SIZE 512u
#define TX_SIZE 8192u
#define CLI_SIZE 48u
#define TEST_MAX_FRAMES 20u
#define TEST_SPACING_US 80000u
#define TEST_RX_WINDOW_US 10000u
#define TEST_MAX_DURATION_US 6000000u
static ZControl control;
static volatile uint8_t uart_rx[RX_SIZE];
static uint8_t uart_tx[TX_SIZE];
static uint32_t rx_pos,tx_in,tx_out,uart_errors;
static char cli_line[CLI_SIZE];
static uint8_t cli_used,cli_reject,pending_cancel,pending_status,pending_help;
static uint16_t pending_count;
static uint8_t test_active,test_radio_ready,radio_state,radio_ok,spi_ok,last_status;
static uint8_t last_reply[23],reply_seen,ce_high;
static uint32_t last_reply_us,ack_count,fail_count,reply_count,bad_reply_count,spi_errors;
static uint32_t uart_dropped_lines,diag_tx_id,diag_done_count,diag_rx_count,diag_timeout_count;
static uint32_t test_started,test_ended,tx_started,pulse_end,next_poll,next_tx,rx_until;
static uint16_t test_target,test_sent;
static uint8_t snapshot_idx,tx_round;
static uint32_t round_started;
/* Round counters are per TEST, unlike lifetime spi_errors and uart_dropped_lines. */
static uint32_t round_txds_count,round_maxrt_count,recovery_count,recovered_ack_count;
static uint32_t recovery_fifo_error_count;
static uint32_t now_us(void) {return TIM5->CNT;}
static int due(uint32_t now,uint32_t at) {return (int32_t)(now-at)>=0;}
static void delay_us(uint32_t n) {uint32_t t=now_us();while((uint32_t)(now_us()-t)<n) {}}
static void ce(int high) {ce_high=(uint8_t)!!high; GPIOE->BSRR=high?(1u<<3):(1u<<19);}
static void cs(int high) {GPIOA->BSRR=high?(1u<<15):(1u<<31);}
static void gpio_af(GPIO_TypeDef *g,unsigned pin,unsigned af,unsigned pull)
{
 g->MODER=(g->MODER&~(3u<<(2u*pin)))|(2u<<(2u*pin));
 g->PUPDR=(g->PUPDR&~(3u<<(2u*pin)))|(pull<<(2u*pin));
 g->AFR[pin/8]=(g->AFR[pin/8]&~(15u<<(4u*(pin%8))))|(af<<(4u*(pin%8)));
}
static void early_gpio(void)
{
 RCC->AHB1ENR|=RCC_AHB1ENR_GPIOAEN|RCC_AHB1ENR_GPIOBEN|RCC_AHB1ENR_GPIOCEN|RCC_AHB1ENR_GPIODEN|RCC_AHB1ENR_GPIOEEN;
 (void)RCC->AHB1ENR;
 ce(0);cs(1); /* Set levels BEFORE changing mode to output. */
 GPIOE->MODER=(GPIOE->MODER&~(3u<<6))|(1u<<6);
 GPIOE->OTYPER&=~(1u<<3);
 GPIOA->MODER=(GPIOA->MODER&~(3u<<30))|(1u<<30);
 GPIOA->OTYPER&=~(1u<<15);
 const uint32_t fields=(3u<<0)|(3u<<14)|(3u<<28);
 GPIOB->MODER=(GPIOB->MODER&~fields)|(1u<<0)|(1u<<14)|(1u<<28);
 GPIOB->OTYPER&=~((1u<<0)|(1u<<7)|(1u<<14));
 GPIOB->BSRR=((1u<<0)|(1u<<7)|(1u<<14))<<16;
 GPIOC->MODER&=~(3u<<26);GPIOC->PUPDR=(GPIOC->PUPDR&~(3u<<26))|(2u<<26);
}
void SystemClock_Config(void)
{
    /* HSI -> PLL: 16/16*336/2=168 MHz. APB1=42, APB2=84 MHz.
     * HSI avoids dependence on ST-LINK MCO / board solder bridges.
     */
    RCC->CR |= RCC_CR_HSION;
    while (!(RCC->CR & RCC_CR_HSIRDY)) {}
    RCC->CFGR &= ~RCC_CFGR_SW;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) {}
    RCC->CR &= ~RCC_CR_PLLON;
    while (RCC->CR & RCC_CR_PLLRDY) {}
    RCC->APB1ENR |= RCC_APB1ENR_PWREN;
    (void)RCC->APB1ENR;
    PWR->CR = (PWR->CR & ~PWR_CR_VOS) | PWR_CR_VOS;
    FLASH->ACR = FLASH_ACR_ICEN | FLASH_ACR_DCEN | FLASH_ACR_PRFTEN
               | FLASH_ACR_LATENCY_5WS;
    RCC->PLLCFGR = 16u | (336u << 6) | (7u << 24); /* PLLP=/2, HSI */
    RCC->CFGR = (RCC->CFGR & ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2))
              | RCC_CFGR_PPRE1_DIV4 | RCC_CFGR_PPRE2_DIV2;
    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY)) {}
    RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL) {}
    SystemCoreClock = 168000000u;
    SysTick->CTRL = 0u; /* timestamps use TIM5, not HAL/SysTick */
}
static void peripherals(void)
{
 RCC->AHB1ENR|=RCC_AHB1ENR_DMA1EN;
 RCC->APB1ENR|=RCC_APB1ENR_TIM5EN|RCC_APB1ENR_USART3EN|RCC_APB1ENR_SPI3EN;
 (void)RCC->APB1ENR;
 TIM5->PSC=83;TIM5->ARR=0xFFFFFFFFu;TIM5->EGR=TIM_EGR_UG;TIM5->CR1=TIM_CR1_CEN;
 gpio_af(GPIOD,8,7,0);gpio_af(GPIOD,9,7,1);
 USART3->CR1=0;USART3->CR2=0;USART3->CR3=USART_CR3_DMAR;
 USART3->BRR=(42000000u+(ZIMANI_DIAG_BAUD/2u))/ZIMANI_DIAG_BAUD;
 DMA1_Stream1->CR=0;while(DMA1_Stream1->CR&DMA_SxCR_EN) {}
 DMA1->LIFCR=0xF40u;DMA1_Stream1->FCR=0;
 DMA1_Stream1->PAR=(uint32_t)(uintptr_t)&USART3->DR;
 DMA1_Stream1->M0AR=(uint32_t)(uintptr_t)uart_rx;DMA1_Stream1->NDTR=RX_SIZE;
 /* AN4031: USART3_RX = DMA1 stream1 channel4. Circular, byte transfers. */
 DMA1_Stream1->CR=(4u<<25)|DMA_SxCR_MINC|DMA_SxCR_CIRC|DMA_SxCR_PL_1|DMA_SxCR_EN;
 USART3->CR1=USART_CR1_UE|USART_CR1_TE|USART_CR1_RE;
 gpio_af(GPIOC,10,6,0);gpio_af(GPIOC,11,6,1);gpio_af(GPIOC,12,6,0);
 GPIOC->OSPEEDR|=(2u<<20)|(2u<<24);
 SPI3->CR1=SPI_CR1_MSTR|SPI_CR1_SSM|SPI_CR1_SSI|SPI_CR1_BR_2;
 SPI3->CR2=0;SPI3->CR1|=SPI_CR1_SPE;
}
static void uart_queue(const char *s);
static int cli_equal(const char *a,const char *b)
{while(*a && *b && *a==*b) {a++;b++;}return *a==0 && *b==0;}
static void cli_line_complete(void)
{
 cli_line[cli_used]=0;
 if(cli_reject) uart_queue("D CMD ok=0 reason=INVALID\r\n");
 else if(cli_equal(cli_line,"HELP")) pending_help=1u;
 else if(cli_equal(cli_line,"STATUS")) pending_status=1u;
 else if(cli_equal(cli_line,"CANCEL")) pending_cancel=1u;
 else if(cli_line[0]=='T' && cli_line[1]=='E' && cli_line[2]=='S' && cli_line[3]=='T' && cli_line[4]==' ') {
   unsigned val=0u;unsigned i=5u;
   if(!cli_line[i]) cli_reject=1u;
   while(!cli_reject && cli_line[i]) {
     if(cli_line[i]<'0'||cli_line[i]>'9') {cli_reject=1u;break;}
     val=val*10u+(unsigned)(cli_line[i]-'0');
     if(val>TEST_MAX_FRAMES) {cli_reject=1u;break;} i++;
   }
   if(!cli_reject && val>=1u) {
     if(test_active||pending_count) uart_queue("D CMD ok=0 reason=BUSY\r\n");
     else pending_count=(uint16_t)val;
   } else uart_queue("D CMD ok=0 reason=COUNT_1_TO_20\r\n");
 } else if(cli_used) uart_queue("D CMD ok=0 reason=UNKNOWN\r\n");
 cli_used=0u;cli_reject=0u;
}
static void uart_byte(uint8_t b)
{
 if(b=='\r') return;
 if(b=='\n') {cli_line_complete();return;}
 if(b<32u||b>126u||cli_used>=CLI_SIZE-1u) {cli_reject=1u;return;}
 if(!cli_reject) cli_line[cli_used++]=(char)b;
}
static void uart_service(void)
{
 uint32_t sr=USART3->SR;
 if(sr&(USART_SR_ORE|USART_SR_FE|USART_SR_NE)) {
   (void)USART3->DR;uart_errors++;pending_cancel=1u;
   cli_used=0u;cli_reject=0u;
   rx_pos=(RX_SIZE-DMA1_Stream1->NDTR)%RX_SIZE;
 }
 if(DMA1->LISR&(DMA_LISR_TEIF1|DMA_LISR_DMEIF1|DMA_LISR_FEIF1)) {
   DMA1->LIFCR=0xF40u;uart_errors++;pending_cancel=1u;
 }
 uint32_t end=(RX_SIZE-DMA1_Stream1->NDTR)%RX_SIZE;
 while(rx_pos!=end) {uint8_t b=uart_rx[rx_pos];rx_pos=(rx_pos+1u)%RX_SIZE;uart_byte(b);}
 if(tx_out!=tx_in && (USART3->SR&USART_SR_TXE)) {
   USART3->DR=uart_tx[tx_out];tx_out=(tx_out+1u)%TX_SIZE;
 }
}
static void uart_queue(const char *s)
{
 uint32_t n=0;while(s[n]) n++;
 uint32_t free=(tx_out+TX_SIZE-tx_in-1u)%TX_SIZE;
 if(n>free) {uart_dropped_lines++; return;} /* Drop whole line, never stall SPI. */
 while(*s) {uart_tx[tx_in]=(uint8_t)*s++;tx_in=(tx_in+1u)%TX_SIZE;}
}
static uint8_t spi(uint8_t b)
{
 uint32_t t=now_us();
 while(!(SPI3->SR&SPI_SR_TXE)) if((uint32_t)(now_us()-t)>500u) {spi_ok=0;return 0xFF;}
 *(volatile uint8_t *)&SPI3->DR=b;
 t=now_us();
 while(!(SPI3->SR&SPI_SR_RXNE)) if((uint32_t)(now_us()-t)>500u) {spi_ok=0;return 0xFF;}
 return *(volatile uint8_t *)&SPI3->DR;
}
static void end_spi(void)
{
 uint32_t t=now_us();
 while(SPI3->SR&SPI_SR_BSY) if((uint32_t)(now_us()-t)>500u) {spi_ok=0;break;}
 cs(1);delay_us(1);
}
static uint8_t radio_cmd(uint8_t cmd)
{cs(0);uint8_t s=spi(cmd);end_spi();return s;}
static void write_reg(uint8_t reg,uint8_t value)
{cs(0);spi((uint8_t)(0x20u|reg));spi(value);end_spi();}
static uint8_t read_reg(uint8_t reg)
{cs(0);spi(reg);uint8_t v=spi(0xFF);end_spi();return v;}
static void write_many(uint8_t cmd,const uint8_t *data,unsigned n)
{cs(0);spi(cmd);for(unsigned i=0;i<n;i++) spi(data[i]);end_spi();}
static void read_many(uint8_t cmd,uint8_t *data,unsigned n)
{cs(0);spi(cmd);for(unsigned i=0;i<n;i++) data[i]=spi(0xFF);end_spi();}
/* Diagnostics are constructed in the main loop; never from an IRQ. */
static void diag_init_event(uint8_t ok);
static void diag_tx_event(uint32_t t,uint32_t id,const uint8_t data[26]);
static void diag_done_event(uint32_t t,uint32_t id,uint8_t result,uint8_t status);
static void diag_round_event(uint32_t t,uint32_t id,uint8_t result,uint8_t status);
static void diag_retry_event(uint32_t t,uint32_t id,uint8_t fifo_before,uint8_t st_after);
static void diag_rx_event(uint32_t t,uint32_t id,const uint8_t *data,uint8_t n,uint8_t valid);
static void diag_bad_width(uint32_t t,uint8_t size);
static void diag_periodic(uint32_t t);
static void diag_snapshot(uint32_t t,uint32_t id,uint32_t elapsed,uint8_t status);
static void diag_cmd_status(void);
static void diag_test_begin(uint32_t t,uint16_t n);
static void diag_test_end(const char *reason);
static int radio_init(void)
{
 static const uint8_t addr[]={ZIMANI_RADIO_ADDRESS};
 uint8_t got[5];ce(0);cs(1);spi_ok=1;
 /* Reinitialize peripheral after any previous bounded SPI timeout. */
 RCC->APB1RSTR|=RCC_APB1RSTR_SPI3RST;RCC->APB1RSTR&=~RCC_APB1RSTR_SPI3RST;
 SPI3->CR1=SPI_CR1_MSTR|SPI_CR1_SSM|SPI_CR1_SSI|SPI_CR1_BR_2|SPI_CR1_SPE;
 /* Captured startup: test address, then two configuration passes (22 -> 23).
  * CE stays low. Timings are conservative design choices, not measured in logs.
  */
 static const uint8_t probe[5]={0xA5,0xA5,0xA5,0xA5,0xA5};
 write_many(0x30,probe,5);read_many(0x10,got,5);
 for(unsigned i=0;i<5;i++) if(got[i]!=probe[i]) return 0;
 for(unsigned pass=0;pass<2;pass++) {
   write_reg(7,0x70);write_reg(0x1C,1);write_reg(0x1D,7);
   /* Compatibility fallback only if FEATURE is locked; not observed in captures. */
   if(read_reg(0x1D)!=7u) {uint8_t a=0x73;write_many(0x50,&a,1);write_reg(0x1D,7);write_reg(0x1C,1);}
   write_reg(0,0x0A);write_reg(1,1);write_reg(2,1);write_reg(3,3);
   write_reg(4,RADIO_RETRIES);write_reg(5,RADIO_CHANNEL);
   write_reg(6,pass?RADIO_RF_SETUP:0x22u);
   write_many(0x30,addr,5);write_many(0x2A,addr,5);
   write_reg(7,0x70);radio_cmd(0xE1);
 }
 radio_cmd(0xE2);
 write_reg(0,0x0A);delay_us(5000);
 if(read_reg(0)!=0x0A||read_reg(1)!=1||read_reg(2)!=1||read_reg(3)!=3
    ||read_reg(4)!=RADIO_RETRIES||read_reg(5)!=RADIO_CHANNEL
    ||(read_reg(6)&0x3Eu)!=(RADIO_RF_SETUP&0x3Eu)
    ||read_reg(0x1D)!=7||read_reg(0x1C)!=1) return 0;
 read_many(0x10,got,5);for(unsigned i=0;i<5;i++) if(got[i]!=addr[i]) return 0;
 read_many(0x0A,got,5);for(unsigned i=0;i<5;i++) if(got[i]!=addr[i]) return 0;
 if(!spi_ok) return 0;
 write_reg(0,0x0B);ce(0);delay_us(150);return spi_ok;
}
static void receive_payloads(void)
{
 for(unsigned k=0;k<3;k++) {
   if(read_reg(0x17)&1u) break;
   uint8_t size=0;read_many(0x60,&size,1);
   if(!size||size>32u) {diag_bad_width(now_us(),size);radio_cmd(0xE2);bad_reply_count++;break;}
   uint8_t data[32];read_many(0x61,data,size);
   uint32_t rx_time=now_us();uint8_t valid=(uint8_t)z_reply_valid(data,size);
   diag_rx_event(rx_time,diag_tx_id,data,size,valid);
   if(valid) {
     for(unsigned i=0;i<23;i++) last_reply[i]=data[i];
     last_reply_us=now_us();reply_seen=1;reply_count++;z_link(&control,last_reply_us);
   } else bad_reply_count++;
 }
 write_reg(7,0x40);
}
/* Manual-only test: no RF init, CE rise, or packet transmission without TEST n. */
static void diag_test_begin(uint32_t t,uint16_t n);
static void diag_test_end(const char *reason);
static void diag_snapshot(uint32_t t,uint32_t id,uint32_t elapsed,uint8_t status);
static void diag_cmd_status(void);
static void shutdown_radio(void)
{
 ce(0);
 if(test_radio_ready && spi_ok) {
   radio_cmd(0xE1);radio_cmd(0xE2);write_reg(7,0x70);
   write_reg(0,0x08); /* RF power-down after the bounded run. */
 }
 ce(0);test_radio_ready=0u;radio_state=0u;radio_ok=0u;
}
static void finish_test(const char *why)
{
 if(!test_active) return;
 shutdown_radio();test_active=0u;test_ended=now_us();diag_test_end(why);
}
static void enter_receive_window(void)
{
 ce(0);receive_payloads();write_reg(7,0x30);write_reg(0,0x0B);
 ce(1);radio_state=3u;rx_until=now_us()+TEST_RX_WINDOW_US;
 next_poll=now_us()+300u;
}
static const uint32_t snap_age_us[]={250u,1000u,3000u,7000u,12000u,17000u,19500u};
static void radio_service(void)
{
 uint32_t t=now_us();
 if(pending_cancel) {
   pending_cancel=0u;pending_count=0u;
   if(test_active) finish_test("CANCEL");
   else uart_queue("D CMD ok=1 idle=1 cancelled=0\r\n");
 }
 if(pending_help) {pending_help=0u;uart_queue("D HELP commands=HELP,STATUS,TEST_n,CANCEL max=20 idle_no_tx=1\r\n");}
 if(pending_status) {pending_status=0u;diag_cmd_status();}
 if(pending_count && !test_active) {
   test_target=pending_count;pending_count=0u;
   test_sent=0u;test_started=now_us();ack_count=0u;fail_count=0u;
   diag_done_count=0u;diag_rx_count=0u;diag_timeout_count=0u;
       round_txds_count=0u;round_maxrt_count=0u;recovery_count=0u;
       recovered_ack_count=0u;recovery_fifo_error_count=0u;
   reply_count=0u;bad_reply_count=0u;
   spi_ok=1u;radio_ok=(uint8_t)radio_init();
   diag_init_event(radio_ok);
   if(!radio_ok) {
     test_radio_ready=spi_ok;
     shutdown_radio();uart_queue("D CMD ok=0 reason=RADIO_INIT_FAILED\r\n");
   } else {
     test_radio_ready=1u;test_active=1u;radio_state=0u;
     next_tx=now_us()+5000u;next_poll=now_us()+150u;
     diag_test_begin(now_us(),test_target);
   }
 }
 t=now_us(); /* Radio init above takes milliseconds; never use the stale pre-init timestamp. */
 if(!test_active) {ce(0);return;} /* HARD GATE: idle must never transmit. */
 if(!spi_ok) {spi_errors++;finish_test("SPI_ERROR");return;}
 if((uint32_t)(t-test_started)>=TEST_MAX_DURATION_US) {finish_test("DEADLINE");return;}
 if(GPIOC->IDR&(1u<<13)) {finish_test("BUTTON");return;}
 /* v8: Unlike v7, never lower CE at pulse_end. Keep CE HIGH throughout
  * first PTX round, during MAX_RT clearing, and throughout recovery.
  * Radio state 1 only allows the >10us CE startup settling time to pass.
  * The 35ms per-round timeout and 6s test deadline remain hard limits.
  */
 if(radio_state==1u && due(t,pulse_end)) {
   radio_state=2u;next_poll=t;
 }
 if(radio_state==2u && due(t,next_poll)) {
   uint8_t st=radio_cmd(0xFF);
   uint32_t elapsed=(uint32_t)(now_us()-round_started);
   last_status=st;next_poll=now_us()+200u;
   if(snapshot_idx<sizeof(snap_age_us)/sizeof(snap_age_us[0]) && elapsed>=snap_age_us[snapshot_idx]) {
     diag_snapshot(now_us(),diag_tx_id,elapsed,st);snapshot_idx++;
   }
   if(st&0x20u) {
     /* A valid ACK is the terminal result for this one logical STOP. */
     round_txds_count++;
     diag_round_event(now_us(),diag_tx_id,1u,st);
     if(tx_round==2u) recovered_ack_count++;
     ack_count++;diag_done_event(now_us(),diag_tx_id,1u,st);
     enter_receive_window();
   } else if(st&0x10u) {
     round_maxrt_count++;
     diag_round_event(now_us(),diag_tx_id,2u,st);
     if(tx_round==1u) {
       /* nRF24L01+: MAX_RT preserves the payload in TX FIFO. On this
        * one permitted CE-HOLD observation, do NOT FLUSH_TX or reload A0.
        * No third phase: tx_round becomes 2 before clearing MAX_RT.
        */
       /* Capture and VERIFY CE remains high. Pulling it low here would
        * revert to the v7 pulse-restart experiment. Do not reload A0. */
       if(!ce_high) {
         fail_count++;diag_done_event(now_us(),diag_tx_id,2u,st);
         finish_test("CE_UNEXPECTED_LOW");return;
       }
       uint8_t fifo_before=read_reg(0x17u);
       if(fifo_before&0x10u) { /* TX_EMPTY: retaining the packet failed. */
         recovery_fifo_error_count++;
         fail_count++;diag_done_event(now_us(),diag_tx_id,2u,st);
         finish_test("FIFO_EMPTY_AFTER_MAX_RT");return;
       }
       write_reg(7u,0x10u); /* Clear only MAX_RT; preserve RX_DR. */
       uint8_t st_after=radio_cmd(0xFF);
       if(!spi_ok||(st_after&0x10u)) {
         fail_count++;diag_done_event(now_us(),diag_tx_id,2u,st);
         finish_test("MAX_RT_CLEAR_FAILED");return;
       }
       /* OEM-inspired hypothesis: with CE already HIGH, clearing MAX_RT
        * lets the nRF radio continue with the retained TX FIFO payload.
        * NO new CE edge and NO W_TX_PAYLOAD are generated here.
        * If the chip does not restart, the second round times out safely.
        */
       recovery_count++;
       tx_round=2u;round_started=now_us();
       radio_state=2u;next_poll=round_started+200u;snapshot_idx=0u;
       diag_retry_event(round_started,diag_tx_id,fifo_before,st_after);
     } else {
       /* The second MAX_RT is final. Only now discard the TX payload. */
       fail_count++;diag_done_event(now_us(),diag_tx_id,2u,st);
       ce(0);radio_cmd(0xE1);enter_receive_window();
     }
   } else if(elapsed>=RADIO_TX_TIMEOUT_US) {
     /* Software timeout is anomalous. Do not add a third RF attempt. */
     diag_timeout_count++;fail_count++;
     diag_round_event(now_us(),diag_tx_id,3u,st);
     diag_done_event(now_us(),diag_tx_id,3u,st);
     ce(0);radio_cmd(0xE1);enter_receive_window();
   }
 } else if(radio_state==3u) {
   if(due(t,next_poll)) {
     uint8_t st=radio_cmd(0xFF);next_poll=now_us()+300u;
     if((st&0x40u)||!(read_reg(0x17)&1u)) receive_payloads();
   }
   if(due(now_us(),rx_until)) {
     ce(0);receive_payloads();radio_state=0u;
     if(test_sent>=test_target) finish_test("COUNT_REACHED");
     else next_tx=now_us()+TEST_SPACING_US;
   }
 } else if(radio_state==0u && due(t,next_tx)) {
   if(test_sent>=test_target) {finish_test("COUNT_REACHED");return;}
   uint8_t payload[26];
   z_stop(&control,FAULT_STOP); /* only hard-coded STOP; no serial motion-control commands accepted */
   z_payload(&control.command,payload);
   ce(0);write_reg(0,0x0A);write_reg(7,0x70);radio_cmd(0xE1);
   write_many(0xA0,payload,26);
   tx_started=now_us();round_started=tx_started;tx_round=1u;
   ce(1);pulse_end=tx_started+20u;radio_state=1u; /* hold CE until DONE */
   test_sent++;snapshot_idx=0u;
   diag_tx_event(tx_started,++diag_tx_id,payload);
 }
 if(!spi_ok) {spi_errors++;finish_test("SPI_ERROR");}
}
static char status_line[640];static unsigned slen;
static void append(const char *s)
{while(*s && slen<sizeof(status_line)-1u) status_line[slen++]=*s++;status_line[slen]=0;}
static void number(uint32_t n)
{char b[10];unsigned k=0;do {b[k++]=(char)('0'+n%10u);n/=10u;}while(n);while(k) {char x[2]={b[--k],0};append(x);}}
static void signed_number(int32_t n) {if(n<0) {append("-");n=-n;}number((uint32_t)n);}
static void hex_bytes(const uint8_t *p,unsigned n)
{
 const char *h="0123456789ABCDEF";
 for(unsigned i=0;i<n;i++) {char b[3]={h[p[i]>>4],h[p[i]&15u],0};append(b);}
}
static void hex_u8(uint8_t v) {hex_bytes(&v,1u);}
static void diag_prefix(const char *type,uint32_t t,uint32_t id)
{
 slen=0;status_line[0]=0;append("D ");append(type);
 append(" us=");number(t);append(" id=");number(id);
}
static void diag_init_event(uint8_t ok)
{
 uint32_t t=now_us();diag_prefix("INIT",t,diag_tx_id);
 append(" ok=");number(ok);
 if(ok) {
   append(" cfg=");hex_u8(read_reg(0u));append(" enaa=");hex_u8(read_reg(1u));
   append(" feat=");hex_u8(read_reg(0x1Du));append(" dyn=");hex_u8(read_reg(0x1Cu));
   append(" ch=");hex_u8(read_reg(5u));append(" rf=");hex_u8(read_reg(6u));
   append(" retr=");hex_u8(read_reg(4u));
 }
 append("\r\n");uart_queue(status_line);
}
static void diag_tx_event(uint32_t t,uint32_t id,const uint8_t data[26])
{
 diag_prefix("TX",t,id);
 append(" ce=");number(ce_high);append(" pay=");hex_bytes(data,26);
 append("\r\n");uart_queue(status_line);
}
/* result: 1=TX_DS, 2=MAX_RT, 3=software timeout. In v8,
 * attempt=2 is only an observation window after clearing MAX_RT with CE HIGH;
 * it does NOT prove that a new physical RF transmission has begun. */
static void diag_round_event(uint32_t t,uint32_t id,uint8_t result,uint8_t status)
{
 uint8_t obs=read_reg(0x08u),fifo=read_reg(0x17u);
 diag_prefix("ROUND",t,id);
 append(" attempt=");number(tx_round);
 append(" ce=");number(ce_high);
 append(" r=");append(result==1u?"TX_DS":(result==2u?"MAX_RT":"TIMEOUT"));
 append(" dt=");number((uint32_t)(t-round_started));
 append(" st=");hex_u8(status);append(" obs=");hex_u8(obs);
 append(" arc=");number(obs&15u);append(" plos=");number(obs>>4);
 append(" fifo=");hex_u8(fifo);append(" rxdr=");number((status>>6)&1u);
 append("\r\n");uart_queue(status_line);
}
static void diag_retry_event(uint32_t t,uint32_t id,uint8_t fifo_before,uint8_t st_after)
{
 diag_prefix("RETRY",t,id);
 append(" attempt=2 reused_fifo=1 fresh_payload=0 mode=CE_HOLD ce_before=1 ce_after=");
 number(ce_high);append(" no_ce_edge=1");
 append(" fifo_before=");hex_u8(fifo_before);
 append(" st_after_clear=");hex_u8(st_after);
 append("\r\n");uart_queue(status_line);
}
static void diag_done_event(uint32_t t,uint32_t id,uint8_t result,uint8_t status)
{
 uint8_t observe=read_reg(0x08u);uint8_t fifo=read_reg(0x17u);
 diag_prefix("DONE",t,id);
 append(" r=");append(result==1u?"TX_DS":(result==2u?"MAX_RT":"TIMEOUT"));
 append(" ce=");number(ce_high);
 append(" attempts=");number(tx_round);
 append(" recovered=");number(result==1u&&tx_round==2u);
 append(" dt=");number((uint32_t)(t-tx_started));
 append(" st=");hex_u8(status);append(" obs=");hex_u8(observe);
 append(" arc=");number(observe&15u);append(" plos=");number(observe>>4);
 append(" fifo=");hex_u8(fifo);append(" rxdr=");number((status>>6)&1u);
 append("\r\n");uart_queue(status_line);diag_done_count++;
}
static void diag_rx_event(uint32_t t,uint32_t id,const uint8_t *data,uint8_t n,uint8_t valid)
{
 diag_prefix("RX",t,id);
 append(" len=");number(n);append(" ok=");number(valid);
 append(" pay=");hex_bytes(data,n);append("\r\n");uart_queue(status_line);
 diag_rx_count++;
}
static void diag_bad_width(uint32_t t,uint8_t size)
{
 diag_prefix("BAD_WIDTH",t,diag_tx_id);
 append(" width=");number(size);append("\r\n");uart_queue(status_line);
}
static void diag_snapshot(uint32_t t,uint32_t id,uint32_t age,uint8_t status)
{
 uint8_t obs=read_reg(0x08),fifo=read_reg(0x17),cfg=read_reg(0x00);
 uint8_t retr=read_reg(0x04),feat=read_reg(0x1D);
 diag_prefix("SNAP",t,id);
 append(" attempt=");number(tx_round);
 append(" age=");number(age);append(" st=");hex_u8(status);
 append(" obs=");hex_u8(obs);append(" fifo=");hex_u8(fifo);
 append(" cfg=");hex_u8(cfg);append(" retr=");hex_u8(retr);
 append(" feat=");hex_u8(feat);append(" ce=");number(ce_high);
 append(" arc=");number(obs&15u);append(" plos=");number(obs>>4);
 append("\r\n");uart_queue(status_line);
}
static void diag_test_begin(uint32_t t,uint16_t n)
{
 diag_prefix("BEGIN",t,diag_tx_id);
 append(" count=");number(n);append(" spacing_us=");number(TEST_SPACING_US);
 append(" rx_us=");number(TEST_RX_WINDOW_US);
 append(" timeout_us=");number(RADIO_TX_TIMEOUT_US);
 append(" recovery_max=1 attempts_max=2 ce_hold=1 retry_edge=0 safe=1 idle_no_tx=1 stop_only=1");append("\r\n");uart_queue(status_line);
}
static void diag_test_end(const char *reason)
{
 diag_prefix("END",now_us(),diag_tx_id);
 append(" reason=");append(reason);
 append(" sent=");number(test_sent);append(" target=");number(test_target);
 append(" ack=");number(ack_count);append(" fail=");number(fail_count);
 append(" timeout=");number(diag_timeout_count);append(" rx=");number(reply_count);
 append(" round_txds=");number(round_txds_count);
 append(" round_maxrt=");number(round_maxrt_count);
 append(" recoveries=");number(recovery_count);
 append(" recovered_acks=");number(recovered_ack_count);
 append(" fifo_error=");number(recovery_fifo_error_count);
 append(" duration_us=");number((uint32_t)(test_ended-test_started));
 append(" ce=");number(ce_high);append(" radio=0 ce_hold=1");append("\r\n");uart_queue(status_line);
}
static void diag_cmd_status(void)
{
 diag_prefix("CMD",now_us(),diag_tx_id);
 append(" ok=1 active=");number(test_active);append(" radio=");number(radio_ok);
 append(" ce=");number(ce_high);append(" sent=");number(test_sent);
 append(" target=");number(test_target);append(" safe=1 idle_no_tx=1");
 append("\r\n");uart_queue(status_line);
}
static void diag_periodic(uint32_t t)
{
 diag_prefix("STAT",t,diag_tx_id);
 append(" ack=");number(ack_count);append(" fail=");number(fail_count);
 append(" done=");number(diag_done_count);append(" timeout=");number(diag_timeout_count);
 append(" recoveries=");number(recovery_count);
 append(" recovered_acks=");number(recovered_ack_count);
 append(" round_maxrt=");number(round_maxrt_count);
 append(" rx=");number(reply_count);append(" rx_all=");number(diag_rx_count);
 append(" badrx=");number(bad_reply_count);append(" spi_err=");number(spi_errors);
 append(" uart_drop=");number(uart_dropped_lines);
 append(" safe=1 active=");number(test_active);append(" ce=");number(ce_high);append(" sent=");number(test_sent);append(" target=");number(test_target);
 append("\r\n");uart_queue(status_line);
}
static void telemetry(void)
{
 uint32_t t=now_us();slen=0;
 append("S v=4 session=");number(control.session);append(" seq=");number(control.seq);
 append(" armed=");number(control.armed);append(" radio=");number(radio_ok);
 append(" fault=");number(control.fault);append(" host_ms=");number(control.host_seen?(t-control.last_host_us)/1000u:999999u);
 append(" link_ms=");number(control.link_seen?(t-control.last_link_us)/1000u:999999u);
 append(" ack=");number(ack_count);append(" fail=");number(fail_count);append(" rx=");number(reply_count);
 append(" badrx=");number(bad_reply_count);append(" reject=");number(control.rejected);
 append(" uart=");number(uart_errors);append(" spi=");number(spi_errors);
 append(" diag=8 safe=1 active=");number(test_active);
 append(" drop=");number(uart_dropped_lines);
 append(" f=");signed_number(control.command.forward);append(" t=");signed_number(control.command.turn);
 append(" blade=");number(control.command.blade);append(" cruise=");number(control.command.cruise);
 append(" light=");number(control.command.light);append(" engine=");number(control.command.engine);
 append(" adjust=");number(control.command.engine_adjust);append(" estop=");number(control.command.estop);
 append(" can_arm=");number(control.can_arm);append(" stop_rx=");number(reply_seen?last_reply[11]:255u);
 append(" rx_ms=");number(reply_seen?(t-last_reply_us)/1000u:999999u);append(" reply=");
 if(reply_seen) {const char *h="0123456789ABCDEF";for(unsigned i=0;i<23;i++) {char b[3]={h[last_reply[i]>>4],h[last_reply[i]&15u],0};append(b);}}
 else append("-");
 append("\r\n");uart_queue(status_line);
}
static void leds(void)
{
 uint32_t t=now_us(),mask=0;
 if(test_active||t%1000000u<100000u) mask|=1u;
 if(radio_ok&&control.link_seen) mask|=1u<<7;
 if(!radio_ok||control.fault||control.command.estop) mask|=1u<<14;
 const uint32_t all=(1u<<0)|(1u<<7)|(1u<<14);
 GPIOB->BSRR=((all&~mask)<<16)|mask;
}
static void watchdog_start(void)
{
 IWDG->KR=0x5555;IWDG->PR=4;IWDG->RLR=499;
 uint32_t t=now_us();while(IWDG->SR) if((uint32_t)(now_us()-t)>10000u) break;
 IWDG->KR=0xAAAA;IWDG->KR=0xCCCC; /* nominal ~1s, LSI tolerance applies */
}
int main(void)
{
 early_gpio();SystemClock_Config();peripherals();z_init(&control);
 z_stop(&control,FAULT_STOP);ce(0);cs(1);radio_ok=0u;
 delay_us(100000u);watchdog_start();
 uart_queue("ZIMANI TX v8 CE HOLD RECOVERY STOP-ONLY; 230400 8N1; IDLE NO RF TX\r\n");
 uart_queue("D IDLE ce=0 radio=0 active=0 safe=1 auto_tx=0 send_TEST_space_10_or_STATUS\r\n");
 uint32_t next_status=now_us(),next_diag=now_us();
 for(;;) {
   uart_service();z_tick(&control,now_us());z_stop(&control,FAULT_STOP);
   radio_service();leds();
   if(due(now_us(),next_diag)) {diag_periodic(now_us());next_diag=now_us()+1000000u;}
   if(due(now_us(),next_status)) {telemetry();next_status=now_us()+500000u;}
   IWDG->KR=0xAAAA;
 }
}
void Error_Handler(void) {ce(0);for(;;) {GPIOB->BSRR=1u<<14;}}
