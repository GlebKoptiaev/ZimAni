#!/usr/bin/env python3
"""Record raw RF sniffer messages from STM32 VCP to a line-oriented UTF-8 log.

Usage: py record_rx.py --port COM5 --out radio_rx.txt [--seconds 30]
Requires: py -m pip install pyserial
"""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import sys
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", required=True, help="COM port of RX-only NUCLEO")
    parser.add_argument("--out", default="radio_rx.txt", help="Output text file")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--seconds", type=float, default=0.0,
                        help="Record duration; 0 until Ctrl+C")
    args = parser.parse_args()
    try:
        import serial
    except ImportError:
        print("Install pyserial: py -m pip install pyserial", file=sys.stderr)
        return 2
    if args.seconds < 0:
        parser.error("--seconds cannot be negative")
    output = Path(args.out)
    deadline = time.monotonic() + args.seconds if args.seconds else None
    print("Opening", args.port, "baud", args.baud, "->", output)
    try:
        with serial.Serial(args.port, args.baud, timeout=0.25) as port, \
             output.open("w", encoding="utf-8", newline="\n") as destination:
            destination.write("#host_start=" + datetime.now(timezone.utc).isoformat() + "\n")
            destination.flush()
            try:
                while deadline is None or time.monotonic() < deadline:
                    line = port.readline()
                    if not line:
                        continue
                    decoded = line.decode("ascii", errors="replace").strip()
                    if not decoded:
                        continue
                    stamp = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
                    text_line = stamp + " " + decoded
                    print(text_line)
                    destination.write(text_line + "\n")
                    destination.flush()
            except KeyboardInterrupt:
                pass
    except OSError as error:
        print("COM or file error:", error, file=sys.stderr)
        return 1
    print("Saved:", output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
