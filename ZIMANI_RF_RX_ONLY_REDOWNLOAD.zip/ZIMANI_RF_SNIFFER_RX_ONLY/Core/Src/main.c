/*
 * ZIMANI RF SNIFFER RX-ONLY v1.0 -- STM32 NUCLEO-F429ZI, Ebyte E01-ML01DP5
 *
 * Purpose: OBSERVE packets from original remote without RF transmission.
 * NO W_TX_PAYLOAD, NO W_ACK_PAYLOAD, NO PTX state, EN_AA=0, PRIM_RX=1.
 * Hardware: CE PE3, CSN PA15, SCK PC10, MISO PC11, MOSI PC12;
 *           USART3 PD8 -> onboard ST-LINK virtual COM port; 115200 8N1.
 *
 * Requires CMSIS STM32F429xx device headers, startup and system_stm32f4xx.c
 * provided by user's STM32CubeIDE project.  No HAL_Init() is used.
 * Based on the register-level clock/SPI/UART plumbing of ZIMANI_TX_v4.
 * All RF settings follow the 2048-frame original_startup1(2).txt capture.
 * This source was NOT tested on a physical board.
 */
#include "stm32f4xx.h"
#include <stdint.h>

#if !defined(STM32F429xx)
#error "Select STM32F429xx as the target MCU"
#endif

#define RF_CHANNEL    0x45u  /* Channel 69: 2469 MHz */
#define RF_SETUP      0x23u  /* 250 kbps (RF_DR_LOW=1, RF_DR_HIGH=0) */
#define RF_CONFIG_RX  0x0Bu  /* EN_CRC=1, CRC=1 byte, PWR_UP=1, PRIM_RX=1 */
#define RF_FEATURE    0x04u  /* EN_DPL only; EN_ACK_PAY=0, EN_DYN_ACK=0 */
#define UART_BAUD     115200u
#define SPI_TIMEOUT_US 600u
#define SNIFFER_ID    "ZIMANI RF SNIFFER RX-ONLY v1.0"

static const uint8_t rx_address[5] = {0xF8u,0xC4u,0x20u,0x43u,0x4Eu};
static uint32_t rx_count, bad_width_count, spi_error_count, init_error_count;
static uint8_t radio_ready, spi_good;
static uint32_t next_init_us, next_stat_us, last_rx_us;

static uint32_t now_us(void) {return TIM5->CNT;}
static int expired(uint32_t now, uint32_t target) {return (int32_t)(now-target)>=0;}
static void delay_us(uint32_t n) {uint32_t start=now_us();while((uint32_t)(now_us()-start)<n) {}}
static void ce(uint32_t high) {GPIOE->BSRR = high?(1u<<3):(1u<<19);}
static void csn(uint32_t high) {GPIOA->BSRR = high?(1u<<15):(1u<<31);}

static void gpio_af(GPIO_TypeDef *g, unsigned pin, unsigned af, unsigned pull)
{
    g->MODER=(g->MODER&~(3u<<(2u*pin)))|(2u<<(2u*pin));
    g->PUPDR=(g->PUPDR&~(3u<<(2u*pin)))|(pull<<(2u*pin));
    g->AFR[pin/8u]=(g->AFR[pin/8u]&~(15u<<(4u*(pin%8u))))|(af<<(4u*(pin%8u)));
}

/* Set safe CE=LOW / CSN=HIGH BEFORE selecting output pin modes. */
static void early_gpio(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN|RCC_AHB1ENR_GPIOBEN
                    |RCC_AHB1ENR_GPIOCEN|RCC_AHB1ENR_GPIODEN|RCC_AHB1ENR_GPIOEEN;
    (void)RCC->AHB1ENR;
    ce(0u);csn(1u);
    GPIOE->MODER=(GPIOE->MODER&~(3u<<6))|(1u<<6);
    GPIOE->OTYPER &= ~(1u<<3);
    GPIOA->MODER=(GPIOA->MODER&~(3u<<30))|(1u<<30);
    GPIOA->OTYPER &= ~(1u<<15);
    /* NUCLEO user LEDs LD1/LD2/LD3: PB0/PB7/PB14. */
    const uint32_t ledfields=(3u<<0)|(3u<<14)|(3u<<28);
    GPIOB->MODER=(GPIOB->MODER&~ledfields)|(1u<<0)|(1u<<14)|(1u<<28);
    GPIOB->OTYPER &= ~((1u<<0)|(1u<<7)|(1u<<14));
    GPIOB->BSRR = ((1u<<0)|(1u<<7)|(1u<<14))<<16;
}

void SystemClock_Config(void)
{
    /* Verified TX-v4 clock topology: internal HSI -> 168MHz core, APB1 42MHz. */
    RCC->CR |= RCC_CR_HSION;
    while(!(RCC->CR&RCC_CR_HSIRDY)) {}
    RCC->CFGR &= ~RCC_CFGR_SW;
    while((RCC->CFGR&RCC_CFGR_SWS)!=RCC_CFGR_SWS_HSI) {}
    RCC->CR &= ~RCC_CR_PLLON;
    while(RCC->CR&RCC_CR_PLLRDY) {}
    RCC->APB1ENR |= RCC_APB1ENR_PWREN;
    (void)RCC->APB1ENR;
    PWR->CR=(PWR->CR&~PWR_CR_VOS)|PWR_CR_VOS;
    FLASH->ACR=FLASH_ACR_ICEN|FLASH_ACR_DCEN|FLASH_ACR_PRFTEN|FLASH_ACR_LATENCY_5WS;
    RCC->PLLCFGR=16u|(336u<<6)|(7u<<24);
    RCC->CFGR=(RCC->CFGR&~(RCC_CFGR_HPRE|RCC_CFGR_PPRE1|RCC_CFGR_PPRE2))
              |RCC_CFGR_PPRE1_DIV4|RCC_CFGR_PPRE2_DIV2;
    RCC->CR |= RCC_CR_PLLON;
    while(!(RCC->CR&RCC_CR_PLLRDY)) {}
    RCC->CFGR=(RCC->CFGR&~RCC_CFGR_SW)|RCC_CFGR_SW_PLL;
    while((RCC->CFGR&RCC_CFGR_SWS)!=RCC_CFGR_SWS_PLL) {}
    SystemCoreClock=168000000u;
    SysTick->CTRL=0u;
}

static void peripherals(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_TIM5EN|RCC_APB1ENR_USART3EN|RCC_APB1ENR_SPI3EN;
    (void)RCC->APB1ENR;
    TIM5->PSC=83u;TIM5->ARR=0xFFFFFFFFu;TIM5->EGR=TIM_EGR_UG;TIM5->CR1=TIM_CR1_CEN;
    /* PD8 is NUCLEO ST-LINK virtual COM TX. No PC -> MCU commands accepted. */
    gpio_af(GPIOD,8u,7u,0u);
    USART3->CR1=0u;USART3->CR2=0u;USART3->CR3=0u;
    USART3->BRR=(42000000u+UART_BAUD/2u)/UART_BAUD;
    USART3->CR1=USART_CR1_UE|USART_CR1_TE;
    gpio_af(GPIOC,10u,6u,0u);
    gpio_af(GPIOC,11u,6u,1u);
    gpio_af(GPIOC,12u,6u,0u);
    GPIOC->OSPEEDR |= (2u<<20)|(2u<<24);
    /* SPI mode 0, MSB first, /32 on 42MHz APB1 = ~1.3125MHz.
     * TX v4 uses the same SPI_CR1_BR_2 setting. */
    SPI3->CR1=SPI_CR1_MSTR|SPI_CR1_SSM|SPI_CR1_SSI|SPI_CR1_BR_2;
    SPI3->CR2=0u;
    SPI3->CR1 |= SPI_CR1_SPE;
}

static void uart_ch(char ch)
{
    while(!(USART3->SR&USART_SR_TXE)) {}
    USART3->DR=(uint8_t)ch;
}
static void uart_text(const char *p) {while(*p) uart_ch(*p++);}
static void uart_dec(uint32_t n)
{
    char b[10];unsigned len=0u;
    do {b[len++]=(char)('0'+n%10u);n/=10u;} while(n);
    while(len) uart_ch(b[--len]);
}
static void uart_hex(uint8_t v)
{
    static const char hexdigits[]="0123456789ABCDEF";
    uart_ch(hexdigits[v>>4]);uart_ch(hexdigits[v&15u]);
}
static void uart_hex_bytes(const uint8_t *data, uint8_t length)
{for(uint8_t i=0;i<length;i++) uart_hex(data[i]);}

static uint8_t spi_byte(uint8_t b)
{
    uint32_t t=now_us();
    while(!(SPI3->SR&SPI_SR_TXE)) if((uint32_t)(now_us()-t)>SPI_TIMEOUT_US) {spi_good=0u;return 0xFFu;}
    *(volatile uint8_t*)&SPI3->DR=b;
    t=now_us();
    while(!(SPI3->SR&SPI_SR_RXNE)) if((uint32_t)(now_us()-t)>SPI_TIMEOUT_US) {spi_good=0u;return 0xFFu;}
    return *(volatile uint8_t*)&SPI3->DR;
}
static void spi_end(void)
{
    uint32_t t=now_us();
    while(SPI3->SR&SPI_SR_BSY) if((uint32_t)(now_us()-t)>SPI_TIMEOUT_US) {spi_good=0u;break;}
    csn(1u);delay_us(1u);
}
static void write_register(uint8_t reg, uint8_t value)
{csn(0u);(void)spi_byte((uint8_t)(0x20u|reg));(void)spi_byte(value);spi_end();}
static uint8_t read_register(uint8_t reg)
{csn(0u);(void)spi_byte(reg);uint8_t value=spi_byte(0xFFu);spi_end();return value;}
static void write_address(uint8_t reg, const uint8_t *data)
{csn(0u);(void)spi_byte((uint8_t)(0x20u|reg));for(unsigned i=0;i<5u;i++) (void)spi_byte(data[i]);spi_end();}
static void read_address(uint8_t reg, uint8_t *data)
{csn(0u);(void)spi_byte(reg);for(unsigned i=0;i<5u;i++) data[i]=spi_byte(0xFFu);spi_end();}
static void rx_command(uint8_t command)
{csn(0u);(void)spi_byte(command);spi_end();}
static uint8_t read_payload_width(void)
{csn(0u);(void)spi_byte(0x60u);uint8_t width=spi_byte(0xFFu);spi_end();return width;}
static void read_payload(uint8_t *data,uint8_t width)
{csn(0u);(void)spi_byte(0x61u);for(unsigned i=0;i<width;i++) data[i]=spi_byte(0xFFu);spi_end();}

static uint8_t radio_check_configuration(void)
{
    uint8_t got[5];read_address(0x0Au,got);
    for(unsigned i=0;i<5u;i++) if(got[i]!=rx_address[i]) return 0u;
    if(read_register(0x01u)!=0x00u) return 0u; /* NEVER send auto ACK */
    if(read_register(0x00u)!=RF_CONFIG_RX) return 0u; /* PRIM_RX must be 1 */
    if(read_register(0x02u)!=0x01u) return 0u;
    if(read_register(0x03u)!=0x03u) return 0u;
    if(read_register(0x05u)!=RF_CHANNEL) return 0u;
    if((read_register(0x06u)&0x28u)!=(RF_SETUP&0x28u)) return 0u;
    if(read_register(0x1Cu)!=0x01u) return 0u;
    if(read_register(0x1Du)!=RF_FEATURE) return 0u;
    return spi_good;
}
static uint8_t radio_initialize(void)
{
    ce(0u);csn(1u);spi_good=1u;
    RCC->APB1RSTR |= RCC_APB1RSTR_SPI3RST;
    RCC->APB1RSTR &= ~RCC_APB1RSTR_SPI3RST;
    SPI3->CR1=SPI_CR1_MSTR|SPI_CR1_SSM|SPI_CR1_SSI|SPI_CR1_BR_2|SPI_CR1_SPE;
    delay_us(2000u);
    /* Configure while powered down and CE=0: no RF transmission. */
    write_register(0x00u,0x08u); /* EN_CRC, PWR_UP=0, PRIM_RX=0 while CE=0 */
    write_register(0x01u,0x00u); /* EN_AA: auto ACK *disabled on all pipes* */
    write_register(0x02u,0x01u); /* EN_RXADDR: pipe 0 only */
    write_register(0x03u,0x03u); /* SETUP_AW: 5-byte address */
    write_register(0x04u,0x00u); /* SETUP_RETR: hardware retries off */
    write_register(0x05u,RF_CHANNEL);
    write_register(0x06u,RF_SETUP);
    write_address(0x0Au,rx_address); /* RX_ADDR_P0 */
    write_register(0x1Du,RF_FEATURE); /* Enable dynamic payloads, not ACK payload */
    if(read_register(0x1Du)!=RF_FEATURE) {
        /* Some devices lock FEATURE until ACTIVATE 0x73. */
        csn(0u);(void)spi_byte(0x50u);(void)spi_byte(0x73u);spi_end();
        write_register(0x1Du,RF_FEATURE);
    }
    write_register(0x1Cu,0x01u); /* DYNPD: dynamic length only on pipe 0 */
    rx_command(0xE2u);          /* FLUSH_RX; never load TX FIFO */
    write_register(0x07u,0x70u); /* Clear IRQ status flags */
    write_register(0x00u,RF_CONFIG_RX); /* PRIM_RX=1; PWR_UP=1 */
    delay_us(2500u);
    if(!radio_check_configuration()) {ce(0u);return 0u;}
    /* EN_AA was just VERIFIED 0: CE HIGH cannot cause automatic ACK TX. */
    ce(1u);
    delay_us(150u);
    return spi_good;
}

static void radio_stop_with_error(const char *message)
{
    ce(0u);
    radio_ready=0u;
    ++spi_error_count;
    uart_text("ERR ");uart_text(message);uart_text("\r\n");
    next_init_us=now_us()+1000000u;
}
static void rx_service(void)
{
    /* RX_FIFO_STATUS bit0=RX_EMPTY. Drain at most three packets per pass. */
    for(unsigned i=0;i<3u;i++) {
        uint8_t fifo=read_register(0x17u);
        if(!spi_good) {radio_stop_with_error("SPI_READ");return;}
        if(fifo&0x01u) break;
        uint8_t width=read_payload_width();
        if(!spi_good) {radio_stop_with_error("SPI_WIDTH");return;}
        if(width==0u||width>32u) {
            ++bad_width_count;
            rx_command(0xE2u);
            uart_text("WARN BAD_WIDTH=");uart_dec(width);uart_text("\r\n");
            break;
        }
        uint8_t data[32];read_payload(data,width);
        if(!spi_good) {radio_stop_with_error("SPI_PAYLOAD");return;}
        ++rx_count;last_rx_us=now_us();
        uart_text("RX us=");uart_dec(last_rx_us);
        uart_text(" n=");uart_dec(rx_count);
        uart_text(" len=");uart_dec(width);
        uart_text(" hex=");uart_hex_bytes(data,width);
        uart_text("\r\n");
        /* Blue LED pulse for every received packet; reset in status loop. */
        GPIOB->BSRR=(1u<<7);
    }
    write_register(0x07u,0x40u); /* Clear RX_DR interrupt, still PRX only. */
    if(!spi_good) radio_stop_with_error("SPI_CLEAR");
}

int main(void)
{
    early_gpio();SystemClock_Config();peripherals();
    delay_us(25000u);
    uart_text(SNIFFER_ID "\r\n");
    uart_text("CH=69 FREQ=2469MHz RATE=250kbps AW=5 CRC=1 DPL=1 EN_AA=0 RX_ONLY=1\r\n");
    uart_text("ADDR=F8C420434E UART=115200 NO_TX_PAYLOAD NO_AUTO_ACK\r\n");
    next_init_us=now_us();next_stat_us=now_us()+1000000u;
    for(;;) {
        uint32_t t=now_us();
        if(!radio_ready && expired(t,next_init_us)) {
            radio_ready=radio_initialize();
            if(radio_ready) uart_text("READY RX_ONLY AA=0\r\n");
            else {
                ++init_error_count;ce(0u);
                uart_text("ERR INIT_CHECK AA_OR_CONFIG_INVALID\r\n");
                next_init_us=now_us()+1000000u;
            }
        }
        if(radio_ready) rx_service();
        t=now_us();
        if(expired(t,next_stat_us)) {
            if(radio_ready && !radio_check_configuration()) {
                radio_stop_with_error("CONFIG_CHANGED_RX_DISABLED");
            }
            /* Green LED = configured RX; red = initialization needed. */
            const uint32_t green=1u<<0,blue=1u<<7,red=1u<<14;
            GPIOB->BSRR = (radio_ready?green:red)
                | ((radio_ready?red:green)<<16) | (blue<<16);
            uart_text("STAT rx=");uart_dec(rx_count);
            uart_text(" bad_width=");uart_dec(bad_width_count);
            uart_text(" init_err=");uart_dec(init_error_count);
            uart_text(" spi_err=");uart_dec(spi_error_count);
            uart_text(" radio=");uart_dec(radio_ready);
            uart_text(" aa=0\r\n");
            next_stat_us=t+1000000u;
        }
    }
}

void Error_Handler(void)
{
    ce(0u);
    for(;;) {GPIOB->BSRR=1u<<14;}
}
