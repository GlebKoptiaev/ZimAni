from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT/'Core/Src/main.c').read_text()
CONF = (ROOT/'Core/Inc/zimani_config.h').read_text()

class Tests(unittest.TestCase):
    def test_idle_radio_hard_gate(self):
        p=SRC.index('static void radio_service(void)\n{')
        self.assertLess(SRC.index('if(!test_active) return;',p),SRC.index('write_many(0xA0,payload,26);',p))
        self.assertNotIn('next_init=',SRC)

    def test_manual_input(self):
        self.assertIn('cli_equal(cli_line,"STATUS")',SRC)
        self.assertIn('cli_equal(cli_line,"CANCEL")',SRC)
        self.assertIn("cli_line[0]=='T'",SRC)
        self.assertNotIn('z_accept(&control',SRC)

    def test_bounded(self):
        self.assertIn('TEST_MAX_FRAMES 20u',SRC)
        self.assertIn('TEST_MAX_DURATION_US 6000000u',SRC)
        self.assertIn('test_sent>=test_target',SRC)
        self.assertIn('finish_test("COUNT_REACHED")',SRC)
        self.assertIn('finish_test("DEADLINE")',SRC)

    def test_off_after_end(self):
        self.assertIn('write_reg(0,0x08); /* RF power-down',SRC)
        self.assertIn('ce(0);test_radio_ready=0u;',SRC)

    def test_radio_init_ce_low(self):
        self.assertIn('write_reg(0,0x0B);ce(0);delay_us(150);return spi_ok;',SRC)
        self.assertIn('test_active=1u;',SRC)

    def test_stop_only(self):
        self.assertIn('z_stop(&control,FAULT_STOP); /* no serial control packets',SRC)
        self.assertIn('ZIMANI_DIAG_STOP_ONLY 1u',CONF)
        self.assertNotIn('z_accept(&control',SRC)

    def test_snapshots_and_end(self):
        for f in ['"SNAP"','"BEGIN"','"END"','"CMD"','"STAT"','"RX"','"TX"']:
            self.assertIn(f,SRC)
        for f in ['" obs="','" fifo="','" cfg="','" retr="','" feat="','" ce="']:
            self.assertIn(f,SRC)
        self.assertRegex(SRC,r'snap_age_us\[\]=\{[^}]+19500u')

    def test_uart_baud(self):
        self.assertIn('ZIMANI_DIAG_BAUD 230400u',CONF)

if __name__=='__main__': unittest.main()
