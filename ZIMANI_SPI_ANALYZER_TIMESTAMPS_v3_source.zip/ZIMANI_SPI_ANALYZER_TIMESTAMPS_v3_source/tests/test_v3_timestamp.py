import unittest
from reader import parse_capture


class TimestampFormatTests(unittest.TestCase):
    def test_v3_values_and_payload(self):
        s = ('#host_request_utc=2026-11-20T11:00:00+00:00 (approximate, not synchronized)\n'
             '#BEGIN version=3 reason=WINDOW flags=0x00000000 frames=2 '
             'complete_bytes=5 raw_mosi=5 raw_miso=5 raw_frames=2 '
             'total_sck=40 raw_times=2 timestamps=exti3_tim5_us '
             'latency=isr not_synchronized=1\n'
             '#F,index,end_sck,end_us,MOSI_hex,MISO_hex\n'
             'F,0,16,150,252A,0E00\n'
             'F,1,40,315,A01122,0E0000\n#END\n')
        meta,rows=parse_capture(s)
        self.assertEqual(meta['version'],'3')
        self.assertEqual([r['end_sck'] for r in rows],[16,40])
        self.assertEqual([r['end_us'] for r in rows],[150,315])
        self.assertEqual(rows[1]['data_hex'],'1122')

    def test_reject_time_out_of_order(self):
        s = ('#BEGIN version=3 reason=WINDOW flags=0 frames=2 '
             'complete_bytes=5 raw_times=2 timestamps=exti3_tim5_us\n'
             'F,0,16,315,252A,0E00\nF,1,40,150,A01122,0E0000\n#END\n')
        with self.assertRaisesRegex(ValueError,'Nonmonotonic'):
            parse_capture(s)

    def test_reject_missing_time_and_mismatch(self):
        s = ('#BEGIN version=3 reason=WINDOW flags=0 frames=1 '
             'complete_bytes=2 raw_times=1 timestamps=exti3_tim5_us\n'
             'F,0,16,100,252A,0E00\n#END\n')
        self.assertEqual(parse_capture(s)[1][0]['end_us'],100)
        with self.assertRaisesRegex(ValueError,'Missing timestamp'):
            parse_capture(s.replace(',16,100,',',16,,'))
        with self.assertRaisesRegex(ValueError,'Different time and frame'):
            parse_capture(s.replace('raw_times=1','raw_times=0'))

if __name__=='__main__':
    unittest.main()
